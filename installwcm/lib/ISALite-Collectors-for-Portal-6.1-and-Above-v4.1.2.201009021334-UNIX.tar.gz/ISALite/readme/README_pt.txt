# (C) COPYRIGHT International Business Machines Corp., 2007
# Todos os direitos reservados * Materiais licenciados - Propriedade da IBM

-------------------------------------------------------------
Ferramenta IBM Support Assistant Lite
-------------------------------------------------------------

Descri��o
---------

A Ferramenta IBM Support Assistant Lite faculta recolhas autom�ticas de dados para produtos IBM. A ferramenta est� pr�-configurada para localizar dados de
diagn�stico importantes no sistema inform�tico do utilizador e copi�-los para um ficheiro
de colector. Um exemplo de dados de diagn�stico � um ficheiro de registo gerado pelo
produto IBM do utilizador que cont�m um hist�rico detalhado dos eventos ocorridos durante
a utiliza��o do produto. Este ficheiro pode ser �til para determinar a natureza e causa
de um problema de software.
Outros exemplos de dados de diagn�stico incluem ficheiros de inicializa��o, ficheiros de
configura��o, vers�o do sistema operativo, espa�o em disco e liga��es de rede.
A ferramenta pode ser executada em modo GUI ou num modo de consola de linha de comandos.
O modo de consola faculta ao utilizador um controlo de linha de comandos dos scripts das recolhas da ferramenta IBM Support Assistant Lite.  Esta ferramenta inclui v�rios componentes que assistem o utilizador na sua interac��o em modo de consola, incluindo um componente que permite gravar as respostas da sess�o em modo de consola num ficheiro e, posteriormente, utilizar o ficheiro para levar a cabo outras execu��es de um script da mesma recolha.  

Instala��o e utiliza��o da ferramenta
---------------------------
Em muitos casos, a seguinte sequ�ncia de passos permite que o utilizador comece a utilizar e executar esta ferramenta.  Caso se depare com problemas, ou pretender mais informa��es sobre qualquer um destes passos, consulte a sec��o que se segue a esta.  

1.	Instalar a ferramenta extraindo os ficheiros do ficheiro de arquivos que gerou e transferiu do sistema do Workbench.
 - Extraia a ferramenta para qualquer direct�rio que pretender.
 - Consulte as sec��es abaixo para obter detalhes sobre como executar as extrac��es.  

2.	Executar a ferramenta no modo GUI ou no modo de consola de linha de comandos. 
 - Siga o procedimento descrito em seguida para configurar a vari�vel de ambiente JAVA_HOME. Depois de ter feito isto, poder� ent�o executar o script de inicializa��o.
 - Ap�s ter iniciado a ferramenta, siga as instru��es dadas abaixo para interagir com a ferramenta � medida que esta executa uma recolha.

Instalar a ferramenta
--------------------
Em todos os casos, a instala��o da ferramenta IBM Support Assistant Lite consiste simplesmente na extrac��o de ficheiros do ficheiro .zip arquivado, o qual o utilizador gerou e transferiu para o sistema do Workbench. Os ficheiros podem ser extra�dos para qualquer localiza��o do sistema de ficheiros que pretender, no sistema em que a ferramenta ser� executada. Esta ac��o ir� criar no direct�rio de destino o subdirect�rio ISALite.


Utiliza��o da ferramenta
-----------
Definir a vari�vel de ambiente JAVA_HOME
Independentemente de se vai utilizar a ferramenta IBM Support Assistant Lite no modo GUI ou no modo de consola de linha de comandos, utilize o mesmo procedimento para inici�-la: invoque o script de inicializa��o apropriado a partir da linha de comandos.  No caso de se tratar de um sistema Windows, estes scripts de inicializa��o s�o ficheiros de lotes (batch).  Noutros ambientes, s�o scripts c�psula (shell).  

Uma vez que a ferramenta � implementada numa aplica��o Java, � necess�rio que o Java se encontre no sistema antes da ferramenta ser iniciada. Se o Java n�o estiver dispon�vel no PATH, ter� de definir a vari�vel de ambiente JAVA_HOME manualmente.
A ferramenta IBM Support Assistant Lite requer JRE vers�o 1.4.2 ou superior e, por isso, � necess�rio certificar-se de que o JRE adequado est� instalado no sistema em que a ferramenta ser� executada. Caso esteja, ir� precisar de lan�ar um comando de sistema operativo espec�fico para definir a vari�vel JAVA_HOME de modo a que aponte para esse JRE. O Microsoft JVM/JDK n�o � suportado. 

Por exemplo, caso tenha jre1.4.2 instalado em
c:\jre1.4.2 numa plataforma Windows, deve definir JAVA_HOME utilizando o seguinte comando:

SET JAVA_HOME=c:\jre1.4.2
NOTA: N�o utilize plicas no valor do comando SET, mesmo que o valor possua espa�os em branco.

Numa plataforma Linux, AIX, Solaris ou iSeries, caso tenha o JRE instalado em
/opt/jre142, deve definir JAVA_HOME utilizando o seguinte comando:

export JAVA_HOME=/opt/jre142


Iniciar a ferramente em modo Swing GUI
------------------------------------
Ser� necess�rio lan�ar o seguinte script de inicializa��o:

- Para o ambiente Windows, o script � o runISALite.bat e encontra-se no direct�rio \ISALite.
- Para os ambientes Linux, AIX, HP-UX e Solaris, o script � o runISALite.sh e encontra-se no direct�rio \ISALite. Certifique-se de que o script runISALite.sh tem permiss�o de execu��o; pode usar o seguinte comando para dar permiss�o de execu��o a este ficheiro: chmod 755 runISALite.sh

O modo GUI n�o � suportado nos ambientes iSeries e zSeries: consulte a sec��o imediatamente a seguir a esta para informa��es sobre como iniciar esta ferramenta em modo de consola de linha de comandos em iSeries e zSeries. 

Iniciar a ferramenta em modo de consola de linha de comandos
-----------------------------------------------
Ser� necess�rio lan�ar o seguinte script de inicializa��o:

- Para o ambiente Windows, o script � o runISALiteConsole.bat e encontra-se no direct�rio \ISALite.
- Para os ambientes Linux, AIX, HP-UX e Solaris, o script � o runISALiteConsole.sh e encontra-se no direct�rio \ISALite. Certifique-se de que o script runISALiteConsole.sh tem permiss�o de execu��o; pode usar o seguinte comando para dar permiss�o de execu��o a este ficheiro: chmod 755 runISALiteConsole.sh
- Para o ambiente iSeries, � o script runISALiteConsole_iseries.sh e encontra-se no direct�rio \ISALite. Certifique-se de que o script runISALiteConsole_iseries.sh tem permiss�o de execu��o; pode usar o seguinte comando para dar permiss�o de execu��o a este ficheiro: chmod 755 runISALiteConsole_iseries.sh
- Para o ambiente zSeries, � o script runISALiteConsole_zseries.sh e encontra-se no direct�rio \ISALite. Certifique-se de que o script runISALiteConsole_zseries.sh tem permiss�o de execu��o; pode usar o seguinte comando para dar permiss�o de execu��o a este ficheiro: chmod 755 runISALiteConsole_zseries.sh	
	
Interactuar com a ferramenta
---------------------------
Quer no modo GUI, quer no modo de consola de linha de comandos ser� pedido ao utilizador que preencha v�rios campos, tais como os de nome e data do ficheiro zip de recolha de dados e de outras informa��es espec�ficas de produtos. Ap�s efectuar estas configura��es, seleccione a op��o de problema e a recolha de dados � executada.

Quando o IBM Support Assistant Lite � executado em modo de texto, n�o existem listas de selec��o ou campos de registos para o utilizador introduzir dados.
Em seu lugar, s�o apresentadas op��es dispon�veis como listas numeradas e o utilizador introduz o n�mero da selec��o e, em seguida, carrega na tecla Enter. Os campos de entrada de dados s�o transformados em pedidos de informa��es nos quais introduz a resposta e, em seguida, prime Enter. Ap�s a conclus�o da recolha de dados, a sa�da de dados � outro ficheiro ZIP que pode ser manualmente transferido novamente para a m�quina na qual o IBM Support Assistant Workbench est� instalado. A partir dessa m�quina, o ficheiro ZIP pode ser enviado para a Assist�ncia t�cnica IBM ou examinado localmente, tal como outras recolhas executadas no IBM Support Assistant Workbench.

Para a ferramenta de recolha, escreva quit no modo de texto, ou fa�a clique no bot�o Sair no modo GUI.

*NOTA: Leia o manual de utiliza��o do IBM Support Assistant para obter informa��es mais detalhadas.

