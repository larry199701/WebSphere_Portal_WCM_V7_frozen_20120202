# (C) COPYRIGHT International Business Machines Corp., 2007
# Tutti i diritti riservati * Materiali su licenza - Propriet� di IBM

-------------------------------------------------------------
Strumento IBM Support Assistant Lite
-------------------------------------------------------------

Descrizione
---------------

Lo strumento IBM Support Assistant Lite fornisce la raccolta automatica dei dati per i prodotti IBM. Lo strumento � preconfigurato per individuare importanti dati diagnostici sul
computer e per copiarli in un file del programma di raccolta. Un esempio di dati diagnostici � un file di log
generato dal prodotto IBM, che contiene una cronologia dettagliata di eventi verificatisi
durante l'attivit� del prodotto. Tale file pu� essere utile per determinare la natura e la causa
di un problema software.
Altri esempi di dati diagnostici includono file di inizializzazione, file di configurazione, versione di
sistema operativo, spazio disco e connessioni di rete.
Lo strumento pu� essere eseguito in modalit� GUI o in modalit� console di riga comandi.
La modalit� console fornisce all'utente il controllo da riga comandi degli script di raccolta di
IBM Support Assistant Lite. Lo strumento contiene alcune funzioni utili per l'interazione in
modalit� console, incluso una funzione che consente di registrare le risposte di una
sessione di modalit� console in un file ed utilizzare in seguito il file per condurre le successive esecuzioni
dello stesso script di raccolta.  

Installazione d utilizzo dello strumento
-----------------------------------------
Nella maggior parte dei casi, la seguente sequenza di passi � in grado di installare ed eseguire lo strumento. Se si verificano problemi o se
si desiderano ulteriori informazioni su uno qualsiasi dei passi, � possibile fare riferimento alle sezioni riportate di seguito a questa.  

1.	Installare lo strumento estraendo i file dal file di archivio generato e trasferito dal sistema Workbench.
 - Estrarre lo strumento in una directory a scelta.
 - Leggere le sezioni riportate di seguito per ulteriori dettagli sull'esecuzione delle estrazioni.  

2.	Eseguire lo strumento in modalit� GUI o in modalit� console di riga comandi. 
 - Seguire la procedura descritta in seguito per l'impostazione della variabile di ambiente JAVA_HOME. Una volta effettuata questa operazione, � possibile eseguire lo script di avvio.
 - Dopo aver avviato lo strumento, seguire le istruzioni riportate di seguito per interagire con esso quando esegue una raccolta.

Installazione dello strumento
-----------------------------
In tutti i casi, l'installazione dello strumento IBM Support Assistant Lite � semplicemente una questione di estrazione dei file dal file .zip archiviato
generato dall'utente e trasferito dal sistema Workbench. I file possono essere estratti in qualunque ubicazione del file system scelta sul sistema in cui verr� eseguito lo strumento. 
In questo nodo verr� creata una sottodirectory ISALite nella directory di destinazione.


Utilizzo dello strumento
------------------------
Impostazione della variabile di ambiente JAVA_HOME
A prescindere dal tipo di modalit� di utilizzo dello strumento IBM Support Assistant Lite, ovvero in modalit� GUI o in modalit� console di riga comandi, viene utilizzata
la stessa procedura per avviarlo: viene richiamato lo script di avvio appropriato da una riga comandi. Nel caso di un sistema Windows, gli script di avvio
sono file batch. Per altri ambienti, sono script di shell.  

Poich� lo strumento viene implementato come applicazione Java, � necessario poter individuare Java prima di poter avviare lo strumento. Se Java
non � disponibile nel PATH, � necessario impostare la variabile di ambiente JAVA_HOME manualmente.
Lo strumento IBM Support Assistant Lite richiede un JRE di livello 1.4.2 o superiore, quindi � necessario prima assicurarsi che sia installato un JRE adatto
sul sistema in cui verr� eseguito lo strumento. Se � installato, � necessario inviare un comando specifico per il sistema operativo per impostare la variabile JAVA_HOME in modo che punti al JRE. Microsoft JVM/JDK non � supportato. 

Ad esempio, se su una piattaforma Windows � installato jre1.4.2 in
c:\jre1.4.2, impostare JAVA_HOME utilizzando il seguente comando:

SET JAVA_HOME=c:\jre1.4.2
NOTA: non utilizzare le virgolette nel valore del comando SET, anche se il valore contiene degli spazi.

Su una piattaforma Linux, AIX, Solaris o iSeries, se si dispone di JRE installato in
/opt/jre142, impostare JAVA_HOME utilizzando il seguente comando:

export JAVA_HOME=/opt/jre142


Avvio dello strumento in modalit� GUI Swing
--------------------------------------------
Sar� necessario inviare il seguente script di avvio:

- Per ambienti Windows, sar� lo script runISALite.bat nella directory \ISALite dello strumento.
- Per ambienti Linux, AIX, HP-UX e Solaris, sar� lo script runISALite.sh nella directory /ISALite dello strumento. Verificare che lo
script runISALite.sh disponga dell'autorizzazione all'esecuzione; � possibile utilizzare
il seguente comando per fornire al file l'autorizzazione all'esecuzione: chmod 755 runISALite.sh

La modalit� GUI non � supportata negli ambienti iSeries e zSeries: per informazioni su come avviare
lo strumento in modalit� console di riga comandi in iSeries e zSeries, consultare la
sezione immediatamente successiva a questa. 

Avvio dello strumento in modalit� console di riga comandi
---------------------------------------------------------
Sar� necessario inviare il seguente script di avvio:

- Per ambienti Windows, sar� lo script runISALiteConsole.bat nella directory \ISALite dello strumento.
- Per ambienti Linux, AIX, HP-UX e Solaris, sar� lo script runISALiteConsole.sh nella directory /ISALite dello strumento. Verificare che lo
script runISALiteConsole.sh disponga dell'autorizzazione all'esecuzione; � possibile utilizzare
il seguente comando per fornire al file l'autorizzazione all'esecuzione: chmod 755 runISALiteConsole.sh
- Per l'ambiente iSeries, sar� lo script runISALiteConsole_iseries.sh nella directory /ISALite dello strumento. Verificare che lo
script runISALiteConsole_iseries.sh disponga dell'autorizzazione all'esecuzione; � possibile utilizzare
il seguente comando per fornire al file l'autorizzazione all'esecuzione: chmod 755 runISALiteConsole_iseries.sh
- Per l'ambiente zSeries, sar� lo script runISALiteConsole_zseries.sh nella directory /ISALite dello strumento. Verificare che lo
script runISALiteConsole_zseries.sh disponga dell'autorizzazione all'esecuzione; � possibile utilizzare
il seguente comando per fornire al file l'autorizzazione all'esecuzione: chmod 755 runISALiteConsole_zseries.sh	
	
Interazione con lo strumento
-----------------------------
Per entrambe le modalit� GUI e console di riga comandi verr� richiesto di configurare diversi campi, come il nome del file zip di raccolta dati e
qualsiasi altra informazione specifica del prodotto. Dopo avere eseguito questa operazione, selezionare l'opzione relativa al problema per eseguire la
raccolta dati.

Quando IBM Support Assistant Lite viene eseguito in modalit� testo, non vi sono elenchi di selezione o campi di immissione per l'input utente.
Le opzioni disponibili sono presentate come elenchi
numerati ed � possibile immettere il numero dell'opzione seguito dal tasto Invio. I campi di
input sono convertiti in richieste in cui si immette la risposta e si preme Invio. Al termine della
raccolta dati, l'output � un altro file ZIP che � possibile trasferire manualmente sulla macchina
in cui � installato IBM Support Assistant Workbench. Da tale macchina, il file ZIP di output
pu� essere inviato al supporto IBM o esaminato localmente, come avviene con altre raccolte eseguite
in IBM Support Assistant Workbench.

Per arrestare lo strumento di raccolta, immettere quit nella modalit� di testo, o fare clic sul pulsante Esci nella modalit� GUI.

*NOTA: per ulteriori dettagli leggere la guida per l'utente di IBM Support Assistant.

