# (C) COPYRIGHT International Business Machines Corp., 2007
# All Rights Reserved * Licensed Materials - Property of IBM

-------------------------------------------------------------
IBM Support Assistant Lite
-------------------------------------------------------------

Beskrivning
------------

Verktyget IBM Support Assistant Lite anv�nds f�r automatisk
datainsamling f�r IBM-produkter. Verktyget �r f�rkonfigurerat f�r
att s�ka upp viktiga fels�kningsdata p� datorn och kopiera dem
till en insamlingsfil. Exempel p� fels�kningsdata �r en loggfil
som genererats av IBM-produkten och som inneh�ller en detaljerad
historik �ver h�ndelser under driften av produkten. En s�dan fil
kan vara till hj�lp vid s�kandet efter orsaken till programfelet.
Andra exempel p� fels�kningsinformation �r initieringsfiler,
konfigurationsfiler samt information om operativsystemversion,
diskutrymme och n�tverksanslutningar. Verktyget kan k�ras i ett
grafiskt gr�nssnitt eller fr�n en kommandokonsol.
Konsoll�get inneh�ller kommandoradskontroller f�r IBM Support
Assistant Lite-insamlingsskript. Verktyget inneh�ller flera
funktioner i konsoll�get. Du kan t.ex. registrera svaren fr�n en
konsolsession i en fil och sedan anv�nda filen n�r du k�r samma
insamlingsskript n�sta g�ng. 

Installation och anv�ndning av verktyget
----------------------------------------
I de flesta fall installerar du och k�r verktyget med hj�lp av
nedanst�ende steg. Om du st�ter p� problem, eller om du vill ha
mer information om n�got av stegen kan du l�sa avsnitten nedanf�r
detta. 

1.	Installera verktyget genom att extrahera filer fr�n arkivfilen
   som skapades och �verf�rdes fr�n Workbench-systemet.
   - Extrahera verktyget till valfri katalog.
   - Anvisningar om hur du extraherar filerna finns nedan. 

2.	K�r verktyget i det grafiska gr�nssnittet eller i kommandol�ge. 
   - F�lj proceduren som beskrivs nedan och ange milj�variabeln
     JAVA_HOME.
     N�r du har gjort det kan du k�ra startskriptet.
   - N�r du har startat verktyget f�ljer du anvisningarna nedan
     om hur du interagerar under insamlingen. 

Installera verktyget
--------------------
Installationen av IBM Support Assistant Lite best�r i att extrahera
filerna i den arkiverade ZIP-filen som skapades och �verf�rdes
fr�n Workbench-systemet. Filerna kan extraheras till valfri plats
i systemet d�r verktyget ska k�ras. Underkatalogen ISALite skapas
i m�lkatalogen. 


Anv�nda verktyget
-----------------
Ange milj�variabeln JAVA_HOME
Oavsett om du anv�nder IBM Support Assistant Lite i det grafiska
gr�nssnittet eller i kommandokonsolen anv�nder du samma procedur
f�r att starta det. Du anropar l�mpligt startskript fr�n en
kommandorad. I Windows �r startskripten batch-filer. I andra
milj�er �r de skalskript. 

Eftersom verktyget har implementerats som en Java-till�mpning
m�ste Java finnas i s�kv�gen innan verktyget kan startas.
Om Java inte finns i PATH m�ste du ange JAVA_HOME-milj�variabeln
manuellt. IBM Support Assistant Lite kr�ver JRE 1.4.2 eller
senare s� kontrollera f�rst att en passande JRE-version har
installerats i det system verktyget ska anv�ndas. Om det har det
m�ste du anv�nda ett operativsystemspecifikt kommando till att
ange JAVA_HOME-variabeln s� att den pekar p� den JRE-versionen.
Microsoft JVM/JDK hanteras inte. 

Om du till exempel har jre1.4.2 installerad i c:\jre1.4.2
p� en Windows-plattform kan du konfigurera JAVA_HOME med f�ljande
kommando:

SET JAVA_HOME=c:\jre1.4.2
Anm. Anv�nd inte citattecken i v�rdet f�r SET-kommandot, �ven om
v�rdet har blanktecken.

Om du har JRE installerad p� /opt/jre142 p� plattformarna Linux,
AIX, Solaris och iSeries kan du ange JAVA_HOME med f�ljande
kommando:

export JAVA_HOME=/opt/jre142


Starta verktyget i Swing-gr�nssnittet
-------------------------------------
K�r f�ljande startskript: 

- Windows: Skriptet runISALite.bat i katalogen \ISALite.
- Linux, AIX, HP-UX och Solaris: Skriptet runISALite.sh i
  katalogen /ISALite. Kontrollera att skriptet runISALite.sh
  har k�rbeh�righet. Du kan anv�nda f�ljande kommando till att
  ge filen k�rbeh�righet: chmod 755 runISALite.sh

Det finns inget grafiskt gr�nssnitt i iSeries eller zSeries.
Mer information om hur du startar verktyget i konsoll�ge i
iSeries och zSeries finns i n�sta avsnitt. 

Starta verktyget i kommandokonsoll�get
--------------------------------------
K�r f�ljande startskript: 

- Windows: Skriptet runISALiteConsole.bat i katalogen \ISALite.
- Linux, AIX, HP-UX och Solaris: Skriptet runISALiteConsole.sh i
  katalogen /ISALite. Kontrollera att skriptet runISALiteConsole.sh
  har k�rbeh�righet. Du kan anv�nda f�ljande kommando till att ge
  filen k�rbeh�righet: chmod 755 runISALiteConsole.sh
- iSeries: Skriptet runISALiteConsole_iseries.sh i katalogen
  /ISALite.
  Kontrollera att skriptet runISALiteConsole_iseries.sh har
  k�rbeh�righet. Du kan anv�nda f�ljande kommando till att ge
  filen k�rbeh�righet: chmod 755 runISALiteConsole_iseries.sh
- zSeries: Skriptet runISALiteConsole_zseries.sh i katalogen
  /ISALite. Kontrollera att skriptet runISALiteConsole_zseries.sh
  har k�rbeh�righet. Du kan anv�nda f�ljande kommando till att ge
  filen k�rbeh�righet: chmod 755 runISALiteConsole_zseries.sh	
	
Interagera med verktyget
------------------------
B�de i gr�nssnittet och i kommandokonsolen f�r du ange v�rden i
flera f�lt, t.ex. namnet p� datainsamlingens ZIP-fil och annan
produktspecifik information. N�r det �r klart v�ljer du
felalternativ och sedan utf�rs datainsamlingen.


N�r IBM Support Assistant Lite k�rs i textl�ge visas inga
vallistor eller inmatningsf�lt f�r indata.
I st�llet visas alternativen som numrerade listor och du v�ljer
alternativ genom att skriva en siffra och trycka p� Enter.
Indataf�lt visas som uppmaningar d�r du anger ett svar och sedan
trycker p� Enter. N�r datainsamlingen �r klar samlas alla utdata
i en ZIP-fil som du kan �verf�ra manuellt till datorn d�r
IBM Support Assistant Workbench �r installerad. D�rifr�n kan
ZIP-filen skickas till IBM Support eller granskas p� plats, p�
samma s�tt som andra insamlingar som g�rs i IBM Support Assistant
Workbench.


Om du vill stoppa insamlingen skriver du "quit" i textl�ge eller
klickar p� Avbryt i gr�nssnittet. 

*Anm. L�s anv�ndarhandboken till IBM Support Assistant om du
beh�ver mer information. 

