# (C) COPYRIGHT International Business Machines Corp., 2007
# Vse pravice so pridr�ane * Licen�no gradivo - Last podjetja IBM

-------------------------------------------------------------
Orodje IBM Support Assistant Lite
-------------------------------------------------------------

Opis
----

Orodje IBM Support Assistant Lite nudi samodejno zbiranje podatkov za IBM-ove izdelke. Orodje je predhodno konfigurirano tako, da najde pomembne diagnosti�ne podatke na va�em ra�unalni�kem sistemu in jih prekopira v datoteko zbiralnika. Primer takih diagnosti�nih podatkov je dnevni�ka datoteka, ki jo generira va� IBM-ov program, ki vsebuje podrobno zgodovino dogodkov, do katerih je pri�lo med operacijo. Taka datoteka je lahko uporabna pri dolo�anju narave in vzroka te�ave v programski opremi.
Drugi primeri diagnosti�nih podatkov vklju�ujejo inicializacijske datoteke, konfiguracijske datoteke, razli�ico operacijskega sistema, prostor na disku in omre�ne povezave. Orodje lahko izvajate v na�inu GUI ali v konzolnem na�inu ukazne vrstice.
Konzolni na�in nudi nadzorovanje ukazne vrstice skriptov za zbiranje aplikacije
IBM Support Assistant Lite. Orodje vklju�uje �tevilne funkcije, ki vam bodo v pomo� pri
delu v konzolnem na�inu, vklju�no s funkcijo, ki omogo�a zapis odgovorov iz seje v
konzolnem na�inu v datoteko in nato uporabo te datoteke za vodenje nadaljnjih izvedb
enakega skripta za zbiranje. 

Namestitev in uporaba orodja
---------------------------
V ve�ini primerov boste z naslednjim zaporedjem korakov pripravili orodje za delo. �e
naletite na te�ave ali �e �elite dodatne informacije o katerem od teh korakov, lahko
preberete spodnje razdelke, ki sledijo temu. 

1.	Orodje namestite tako, da ekstrahirate datoteke iz arhivske datoteke, ki ste jo generirali in prenesli iz sistema Workbench.
 - Orodje ekstrahirajte v katerikoli imenik, ki ga izberete.
 - V spodnjih razdelkih preberite, kako izvesti ekstrahiranje. 

2.	Orodje za�enite v na�inu GUI ali v konzolnem na�inu ukazne vrstice. 
 - Sledite postopku, opisanem spodaj, za nastavitev spremenljivke okolja JAVA_HOME. Ko kon�ate, lahko izvr�ite zagonski skript.
- Po zagonu orodja sledite spodnjim navodilom za delom z njim, med tem ko izvaja zbiranje. 

Namestitev orodja
--------------------
V vseh primerih je namestitev orodja IBM Support Assistant Lite stvar ekstrahiranja
datotek iz arhivske datoteke .zip, ki ste jih generirali in prenesli iz sistema
Workbench. Datoteke lahko ekstrahirate v katerokoli lokacijo v datote�nem sistemu, ki jo
izberete v sistemu, v katerem boste uporabljali orodje. S tem boste pod ciljnim imenikom
izdelali podimenik ISALite.


Uporaba orodja
-----------
Nastavitev spremenljivke okolja JAVA_HOME
Ne glede na to, ali boste uporabljali orodje IBM Support Assistant Lite v na�inu GUI
ali v konzolnem na�inu ukazne vrstice, boste za njegov zagon uporabili enak postopek:
iz ukazne vrstice boste poklicali ustrezen zagonski skript. V primeru sistema Windows so
ti zagonski skripti paketne datoteke, za druga okolja pa skripti lupine.

Ker se izvaja orodje kot aplikacija Java, je pred zagonom orodja potrebno poiskati Javo. �e
Java ni na voljo na poti, boste morali ro�no nastaviti spremenljivko okolja JAVA_HOME.
Orodje IBM Support Assistant Lite zahteva JRE ravni 1.4.2 ali vi�je, zato morate najprej
zagotoviti, da je v sistemu, v katerem boste uporabljali orodje, name��en ustrezen JRE. �e
je, potem boste morali izdati ukaz, specifi�en za operacijski sistem, s katerim boste
nastavili spremenljivko JAVA_HOME tako, da bo kazala na ta JRE. Microsoft JVM/JDK ni podprt. 

�e imate na primer na platformi Windows name��en jre1.4.2 na c:\jre1.4.2, spremenljivko JAVA_HOME nastavite z ukazom:

SET JAVA_HOME=c:\jre1.4.2
OPOMBA: Za vrednost v ukazu SET ne uporabljajte navednic, �eprav so v va�i vrednosti presledki.

�e imate na platformah sistemov Linux, AIX, Solaris ali iSeries name��en JRE  v /opt/jre142, spremenljivko JAVA_HOME nastavite z ukazom:

export JAVA_HOME=/opt/jre142


Zagon orodja v na�inu Swing GUI
------------------------------------
Izdati boste morali naslednji zagonski skript:

- Za okolje Windows boste uporabili skript runISALite.bat v imeniku orodja \ISALite.
- Za okolja Linux, AIX, HP-UX in Solaris boste uporabili skript runISALite.sh v imeniku
orodja /ISALite. Prepri�ajte se, ali ima skript runISALite.sh dovoljenje za
izvajanje. Z naslednjim ukazom lahko dodelite dovoljenje za izvajanje datoteke: chmod 755 runISALite.sh

Na�in GUI ni podprt v okoljih iSeries in zSeries. Informacije o tem, kako
zagnati orodje v konzolnem na�inu ukazne vrstice v sistemih iSeries in zSeries, boste
na�li v razdelku, ki sledi za tem. 

Zagon orodja v konzolnem na�inu ukazne vrstice
-----------------------------------------------
Izdati boste morali naslednji zagonski skript:

- Za okolje Windows boste uporabili skript runISALiteConsole.bat v imeniku orodja \ISALite.
- Za okolja Linux, AIX, HP-UX in Solaris boste uporabili skript runISALiteConsole.sh v
imeniku orodja /ISALite. Prepri�ajte se, ali ima skript runISALiteConsole.sh
dovoljenje za izvajanje. Z naslednjim ukazom lahko dodelite dovoljenje za izvajanje
datoteke: chmod 755 runISALiteConsole.sh.
- Za okolje iSeries boste uporabili skript runISALiteConsole_iseries.sh v imeniku
orodja /ISALite. Prepri�ajte se, ali ima skript runISALiteConsole_iseries.sh
dovoljenje za izvajanje. Z naslednjim ukazom lahko dodelite dovoljenje za izvajanje
datoteke: chmod 755 runISALiteConsole_iseries.sh.
- Za okolje zSeries boste uporabili skript runISALiteConsole_zseries.sh v imeniku
orodja /ISALite. Prepri�ajte se, ali ima skript runISALiteConsole_zseries.sh
dovoljenje za izvajanje. Z naslednjim ukazom lahko dodelite dovoljenje za izvajanje
datoteke: chmod 755 runISALiteConsole_zseries.sh.
	
Delo z orodjem
---------------------------
Za na�in GUI in za konzolni na�in z ukazno vrstico boste morali nastaviti ve� polj,
kot so ime datoteke zip. zbiranja podatkov in druga polja z informacijami, specifi�nimi
za izdelek.

				Nato izberite �e mo�nost te�ave in s tem se izvede zbiranje podatkov.


�e se izvaja aplikacija IBM Support Assistant Lite v besedilnem na�inu, za vnos uporabni�kih podatkov ne obstajajo nobeni izbirni seznami ali vnosna polja.
Namesto tega so razpolo�ljive izbire predstavljene v obliki o�tevil�enih seznamov, vi pa samo vnesete �tevilko izbire in pritisnete tipko Enter. Vnosna polja so pretvorjena v pozive, ob katerih vnesete va� odgovor in pritisnete Enter. Ko
je zbiranje podatkov dokon�ano, se izhodni podatki zapi�ejo v obliki datoteke
zip, ki jo lahko ro�no prenesete nazaj na ra�unalnik, kjer je name��en IBM
Support Assistant Workbench. Nato lahko izhodno datoteko ZIP po�ljete IBM-ovi
slu�bi za podporo ali jo pregledate. To lahko storite tudi z vsemi zbirkami,
zbranimi v programu IBM Support Assistant Workbench.


�e �elite zaustaviti orodje zbiralnika, v besedilnem na�inu vpi�ite quit ali pa v na�inu
GUI kliknite Kon�aj. 

*OPOMBA: Za nadaljnje podrobnosti preberite vodi� za uporabnika aplikacije IBM Support Assistant.

