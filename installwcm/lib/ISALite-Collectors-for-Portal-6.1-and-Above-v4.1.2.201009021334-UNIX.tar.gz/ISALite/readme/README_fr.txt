# (C) COPYRIGHT International Business Machines Corp., 2007
# All Rights Reserved * El�ments sous licence - Propri�t� d'IBM

-------------------------------------------------------------
Outil IBM Support Assistant Lite
-------------------------------------------------------------

Description
---------------

L'outil IBM Support Assistant Lite effectue automatiquement la collecte des donn�es pour les produits IBM. L'outil est pr�configur� pour localiser les donn�es de diagnostic importantes sur votre ordinateur et les copier dans un fichier de collecteur. Le fichier journal g�n�r� par votre produit IBM et contenant l'historique d�taill� des �v�nements survenus durant le fonctionnement du produit est un exemple de donn�e de diagnostic. Un tel fichier peut �tre utilis� pour d�terminer la nature et la cause d'un incident logiciel.
Les fichiers d'initialisation, les fichiers de configuration, la version du syst�me d'exploitation, l'espace disque et les connexions r�seau sont �galement des donn�es de diagnostic.
Il est possible d'ex�cuter l'outil en mode interface graphique ou en mode console de ligne de commande.
Le mode console vous offre un contr�le de ligne de commande des scripts de collecte IBM Support Assistant Lite. L'outil inclut plusieurs fonctions qui vous assistent lorsque vous interagissez en mode console, notamment une fonction qui vous permet d'enregistrer vos r�ponses dans un fichier � partir d'une session en mode console, puis d'utiliser le fichier pour lancer des ex�cutions ult�rieures du m�me script de collecte.  

Installation et utilisation de l'outil
---------------------------
Dans la plupart des cas, la s�quence d'�tapes suivante permet une mise en route de l'outil. Si vous rencontrez des probl�mes ou si vous avez besoin d'informations suppl�mentaires sur l'une des �tapes, vous pouvez consulter les sections qui suivent la pr�sente section. 

1.	Installez l'outil en proc�dant � l'extraction des fichiers du fichier archive que vous avez g�n�r� et transf�r� � partir du syst�me du plan de travail.
 - Extrayez l'outil dans le r�pertoire de votre choix.
 - Reportez-vous aux sections ci-dessous pour obtenir des d�tails sur les modalit�s d'ex�cution des extractions. 

2.	Ex�cutez l'outil en mode interface graphique ou en mode console de ligne de commande. 
 - Suivez la proc�dure d�crite ci-dessous pour d�finir la variable d'environnement JAVA_HOME. Apr�s quoi, vous pouvez ex�cuter le script de lancement.
 - Une fois que vous avez lanc� l'outil, suivez les instructions ci-dessous pour interagir avec ce dernier au moment d'une collecte.

Installation de l'outil
--------------------
Dans tous les cas, l'installation de l'outil IBM Support Assistant Lite consiste simplement � extraire les fichiers du fichier .zip archiv� que vous avez g�n�r� et transf�r� � partir du syst�me du plan de travail. Il est possible d'extraire les fichiers vers n'importe quel emplacement de syst�me de fichiers que vous choisissez, sur le syst�me o� vous ex�cuterez l'outil. Un sous-r�pertoire ISALite est ainsi cr�� sous votre r�pertoire cible.


Utilisation de l'outil
-----------
D�finition de la variable d'environnement JAVA_HOME
Quel que soit le mode d'utilisation de l'outil IBM Support Assistant Lite (interface graphique ou console de ligne de commande), vous utilisez la m�me proc�dure pour le d�marrer : vous appelez le script de lancement appropri� � partir d'une ligne de commande. Dans le cas d'un syst�me Windows, ces scripts de lancement sont des fichiers de commandes. Pour les autres environnements, il s'agit de scripts de shell. 

Etant donn� que l'outil est impl�ment� en tant qu'application Java, il est n�cessaire que Java puisse �tre localis� avant que l'outil puisse d�marrer. Si Java n'est pas disponible sur PATH, vous devez d�finir la variable d'environnement JAVA_HOME manuellement.
L'outil IBM Support Assistant Lite requiert un environnement JRE de niveau 1.4.2 ou sup�rieur ; vous devez donc vous assurer, dans un premier temps, qu'un environnement JRE ad�quat est install� sur le syst�me o� l'outil sera ex�cut�. Si tel est le cas, vous devez �mettre une commande propre au syst�me d'exploitation pour d�finir la variable JAVA_HOME de fa�on � ce qu'elle pointe vers cet environnement JRE. Microsoft JVM/JDK n'est pas pris en charge. 

Par exemple, si sur une plateforme Windows, jre1.4.2 est install� � l'emplacement
c:\jre1.4.2, vous devez configurer la variable JAVA_HOME avec la commande suivante :

SET JAVA_HOME=c:\jre1.4.2
REMARQUE : n'utilisez pas de guillemets dans la valeur de la commande SET, m�me si votre valeur comporte des espaces vides.

Sur une plateforme Linux, AIX, Solaris ou iSeries, si JRE est install� � l'emplacement /opt/jre142, vous devez configurer la variable JAVA_HOME avec la commande suivante :

export JAVA_HOME=/opt/jre142


D�marrage de l'outil en mode interface graphique Swing
------------------------------------
Vous devez �mettre le script de lancement suivant :

- Environnement Windows : script runISALite.bat dans le r�pertoire \ISALite de l'outil.
- Environnements Linux, AIX, HP-UX et Solaris : script runISALite.sh dans le r�pertoire /ISALite de l'outil. Assurez-vous que le script runISALite.sh dispose d'un droit d'ex�cution. Vous pouvez utiliser la commande suivante pour attribuer au fichier un droit d'ex�cution : chmod 755 runISALite.sh

Le mode interface graphique n'est pas pris en charge dans les environnements iSeries et zSeries ; consultez la section qui suit imm�diatement la pr�sente section pour obtenir des informations sur les modalit�s de d�marrage de l'outil en mode console de ligne de commande sous iSeries et zSeries. 

D�marrage de l'outil en mode console de ligne de commande
-----------------------------------------------
Vous devez �mettre le script de lancement suivant :

- Environnement Windows : script runISALiteConsole.bat dans le r�pertoire \ISALite de l'outil.
- Environnements Linux, AIX, HP-UX et Solaris : script runISALiteConsole.sh dans le r�pertoire /ISALite de l'outil. Assurez-vous que le script runISALiteConsole.sh dispose d'un droit d'ex�cution. Vous pouvez utiliser la commande suivante pour attribuer au fichier un droit d'ex�cution : chmod 755 runISALiteConsole.sh. Assurez-vous que le script                runISALiteConsole_iseries.sh dispose d'un droit d'ex�cution. Vous pouvez utiliser la commande suivante pour attribuer au fichier un droit d'ex�cution : chmod 755 runISALiteConsole_iseries.sh
- Environnement zSeries : script runISALiteConsole_zseries.sh dans le r�pertoire /ISALite de l'outil. Assurez-vous que le script runISALiteConsole_zseries.sh dispose d'un droit d'ex�cution. Vous pouvez utiliser la commande suivante pour attribuer au fichier un droit d'ex�cution : chmod 755 runISALiteConsole_zseries.sh	
	
Interaction avec l'outil
---------------------------
Pour le mode interface graphique et le mode console de ligne de commande, vous �tes invit� � d�finir plusieurs zones, telles que le nom du fichier zip de collecte de donn�es et toute autre information propre au produit. Ensuite, vous s�lectionnez l'option d'incident et la collecte de donn�es est effectu�e.

Lorsque l'outil IBM Support Assistant Lite s'ex�cute en mode texte, il ne comporte aucune liste de s�lection ou zone de saisie destin�e � l'utilisateur. Les choix disponibles sont pr�sent�s sous la forme de listes num�rot�es ; vous entrez le num�ro de votre s�lection et vous appuyez sur la touche Entr�e. Les zones de saisie sont transform�es en invites, dans lesquelles vous entrez votre r�ponse avant d'appuyer sur la touche Entr�e. Lorsque la collecte de donn�es est termin�e, il en r�sulte un autre fichier zip que vous pouvez manuellement transf�rer � nouveau vers la machine sur laquelle IBM Support Assistant Workbench est install�. A partir de l�, le fichier zip de sortie peut �tre envoy� au support IBM ou examin� en local, comme dans le cas des autres collectes effectu�es dans IBM Support Assistant Workbench.

Pour arr�ter l'outil de collecte, entrez quit en mode texte ou cliquez sur le bouton Quitter en mode interface graphique.

*REMARQUE : veuillez lire le guide d'utilisation d'IBM Support Assistant pour plus de d�tails.

