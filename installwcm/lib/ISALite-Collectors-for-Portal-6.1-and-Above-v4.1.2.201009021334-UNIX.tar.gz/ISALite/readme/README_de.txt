# (C) COPYRIGHT International Business Machines Corp., 2007
# All Rights Reserved * Licensed Materials - Property of IBM
# (C) COPYRIGHT IBM Deutschland GmbH, 2007
# Alle Rechte vorbehalten * Lizenzmaterial - Eigentum von IBM

-------------------------------------------------------------
IBM Support Assistant Lite Tool
-------------------------------------------------------------

Beschreibung
------------

Das Tool IBM Support Assistant Lite erm�glicht eine automatische Erfassung von Daten f�r IBM Produkte. Das
Tool ist so vorkonfiguriert, dass es wichtige Diagnosedaten auf Ihrem Computersystem aufsp�rt und in eine
Collectordatei kopiert. Ein Beispiel von Diagnosedaten ist eine Protokolldatei, die Ihr IBM Produkt generiert
hat und ein detailliertes Verlaufsprotokoll von Ereignissen enth�lt, die w�hrend des Betriebs der Software
eintreten. Eine solche Datei kann bei der Ermittlung der Spezifik und der Ursache eines Softwareproblems
n�tzlich sein.
Initialisierungsdateien, Konfigurationsdateien, die Betriebssystemversion, der Plattenspeicherplatz und die
Netzverbindungen sind weitere Beispiele f�r derartige Diagnosedaten.
Das Tool kann im GUI-Modus oder in einem Befehlszeilenkonsolmodus ausgef�hrt werden.
Der Konsolmodus erm�glicht Ihnen die Steuerung der Erfassungsscripts von IBM Support Assistant Lite
�ber die Befehlszeile. Das Tool umfasst verschiedene Funktionen, die Sie unterst�tzen, wenn Sie
mit dem Tool im Konsolmodus interagieren. Dazu geh�rt auch eine Funktion zur Aufzeichnung Ihrer
Antworten aus einer Konsolmodussitzung in einer Datei, die Sie anschlie�end zur Steuerung nachfolgender
Ausf�hrungen desselben Erfassungsscripts verwenden k�nnen.  

Installation und Verwendung des Tools
-------------------------------------
In den meisten F�llen k�nnen Sie das Tool in den folgenden Schritten installieren und einsatzbereit
machen. Wenn Probleme auftreten oder weitere Informationen zu einem dieser Schritte gew�nscht werden,
k�nnen Sie die Abschnitte lesen, die auf diesen Abschnitt folgen. 

1.	Installieren Sie das Tool, indem Sie die Dateien aus dem Archiv extrahieren, das Sie aus dem Workbench-System
generiert und �bertragen haben.
 - Extrahieren Sie das Tool in ein beliebiges Verzeichnis, das Sie ausw�hlen.
 - In den nachfolgenden Abschnitten finden Sie detaillierte Informationen zur Ausf�hrung der Extraktionen. 

2.	F�hren Sie das Tool entweder im GUI-Modus oder im Befehlszeilenkonsolmodus aus. 
 - F�hren Sie die unten beschriebene Prozedur aus, um die Umgebungsvariable JAVA_HOME einzustellen. Anschlie�end
   k�nnen Sie das Startscript ausf�hren.
 - Nach dem Start des Tools befolgen Sie die unten beschriebenen Anweisungen zur Interaktion mit dem Tool w�hrend
   der Ausf�hrung einer Erfassung. 

Installation des Tools
----------------------
In allen F�llen besteht die Installation des Tools IBM Support Assistant Lite lediglich darin, die Dateien aus
der ZIP-Archivdatei zu extrahieren, die Sie generiert und vom Workbench-System �bertragen haben. Die Dateien k�nnen
an eine beliebige Dateisystemposition extrahiert werden, die Sie auf dem System ausw�hlen, auf dem das Tool
ausgef�hrt werden soll. Durch diesen Vorgang wird ein Unterverzeichnis 'ISALite' unter Ihrem Zielverzeichnis
erstellt. 


Verwendung des Tools
--------------------
Einstellen der Umgebungsvariablen JAVA_HOME
Unabh�ngig davon, ob Sie das Tool IBM Support Assistant Lite im GUI-Modus oder im Befehlszeilenkonsolmodus verwenden
wollen, verwenden Sie zum Starten des Tools dieselbe Prozedur: Sie rufen das entsprechende Startscript �ber eine
Befehlszeile auf. Bei einem Windows-System sind diese Startscripts Batchdateien. In anderen Umgebungen sind sie
Shell-Scripts. 

Da das Tool als Java-Anwendung implementiert ist, muss Java auffindbar sein, bevor das Tool gestartet werden kann.
Wenn Java in der Variablen PATH nicht verf�gbar ist, m�ssen Sie die Umgebungsvariable JAVA_HOME manuell festlegen.
Das Tool IBM Support Assistant Lite erfordert Java Runtime Environment (JRE) 1.4.2 oder eine h�here Version.
Daher m�ssen Sie zun�chst sicherstellen, dass eine entsprechende JRE auf dem System installiert ist, auf dem das
Tool ausgef�hrt werden soll. Ist eine solche JRE vorhanden, m�ssen Sie mithilfe eines betriebssystemspezifischen
Befehls die Variable JAVA_HOME so definieren, dass sie auf diese JRE verweist. Das Microsoft JVM/JDK wird nicht
unterst�tzt. 

Wenn zum Beispiel auf einer Windows-Plattform die JRE 'jre1.4.2' im Verzeichnis 'c:\jre1.4.2' installiert ist,
m�ssen Sie die Variable JAVA_HOME mit folgendem Befehl festlegen: 

SET JAVA_HOME=c:\jre1.4.2
HINWEIS: Geben Sie keine Anf�hrungszeichen im Wert f�r den Befehl SET an, auch wenn der Wert Leerzeichen enth�lt.

Auf einer Linux-, AIX-, Solaris- oder iSeries-Plattform m�ssen Sie JAVA-HOME mit folgendem Befehl festlegen,
wenn die JRE im Verzeichnis /opt/jre142 installiert ist:

export JAVA_HOME=/opt/jre142


Starten des Tools im Swing-GUI-Modus
------------------------------------
Sie m�ssen das folgende Startscript ausf�hren: 

- F�r die Windows-Umgebung ist das Script 'runISALite.bat' im Verzeichnis '\ISALite' des Tools verf�gbar.
- F�r die Linux-, AIX-, HP-UX- und Solaris-Umgebungen ist das Script 'runISALite.sh' im Verzeichnis '/ISALite' des
  Tools verf�gbar. Stellen Sie sicher, dass das Script 'runISALite.sh' die Ausf�hrungsberechtigung hat. Mit dem
  folgenden Befehl k�nnen Sie der Datei die Ausf�hrungsberechtigung erteilen: chmod 755 runISALite.sh

Der GUI-Modus wird in iSeries- und zSeries-Umgebungen nicht unterst�tzt. Informationen zum Starten des Tools
im Befehlszeilenkonsolmodus auf iSeries- und zSeries-Systemen finden Sie im n�chsten Abschnitt. 

Starten des Tools im Befehlszeilenkonsolmodus
---------------------------------------------
Sie m�ssen das folgende Startscript ausf�hren: 

- F�r die Windows-Umgebung ist das Script 'runISALiteConsole.bat' im Verzeichnis '\ISALite' des Tools verf�gbar.
- F�r die Linux-, AIX-, HP-UX- und Solaris-Umgebungen ist das Script 'runISALiteConsole.sh' im Verzeichnis '/ISALite' des
  Tools verf�gbar. Stellen Sie sicher, dass das Script 'runISALiteConsole.sh' die Ausf�hrungsberechtigung hat. Mit dem
  folgenden Befehl k�nnen Sie der Datei die Ausf�hrungsberechtigung erteilen: chmod 755 runISALiteConsole.sh
- F�r die iSeries-Umgebung ist das Script 'runISALiteConsole_iseries.sh' im Verzeichnis '/ISALite' des Tools verf�gbar.
  Stellen Sie sicher, dass das Script 'runISALiteConsole_iseries.sh' die Ausf�hrungsberechtigung hat. Mit dem
  folgenden Befehl k�nnen Sie der Datei die Ausf�hrungsberechtigung erteilen: chmod 755 runISALiteConsole_iseries.sh
- F�r die zSeries-Umgebung ist das Script 'runISALiteConsole_zseries.sh' im Verzeichnis '/ISALite' des Tools verf�gbar.
  Stellen Sie sicher, dass das Script 'runISALiteConsole_zseries.sh' die Ausf�hrungsberechtigung hat. Mit dem
  folgenden Befehl k�nnen Sie der Datei die Ausf�hrungsberechtigung erteilen: chmod 755 runISALiteConsole_zseries.sh	
	
Interaktion mit dem Tool
------------------------
Sowohl im GUI-Modus als auch im Befehlszeilenkonsolmodus werden Sie aufgefordert, einige Felder zu konfigurieren, wie
zum Beispiel den Namen der ZIP-Datei der Datenerfassung und weitere produktspezifische Informationen. Anschlie�end w�hlen
Sie die Problem-/Fehleroption aus und die Datenerfassung wird ausgef�hrt.

Wenn IBM Support Assistant Lite im Textmodus ausgef�hrt wird, sind keine Auswahllisten oder Eingabefelder f�r
Benutzereingaben verf�gbar. Stattdessen werden die verf�gbaren Auswahlm�glichkeiten in Form von nummerierten
Listen angezeigt. Um eine Option auszuw�hlen, geben Sie die Nummer f�r die entsprechende Auswahlm�glichkeit ein
und dr�cken anschlie�end die Eingabetaste. Eingabefelder werden in Eingabeaufforderungen umgesetzt, in die Sie
Ihre Antwort eingeben und anschlie�end die Eingabetaste dr�cken. Die Ausgabe nach Abschluss der Datenerfassung
erfolgt in Form einer weiteren ZIP-Datei, die manuell auf das System zur�ck�bertragen werden kann, auf dem IBM
Support Assistant Workbench installiert ist. Von dort kann die Ausgabe-ZIP-Datei an die IBM Unterst�tzungsfunktion
gesendet werden oder - wie andere Erfassungen, die in IBM Support Assistant Workbench ausgef�hrt werden - lokal
untersucht werden.

Zum Stoppen des Collector-Tools geben Sie den Befehl 'quit' im Textmodus ein oder klicken im GUI-Modus auf die
Schaltfl�che 'Beenden'. 

*HINWEIS: Weitere detaillierte Informationen finden Sie im Benutzerhandbuch zu IBM Support Assistant.

