# (C) COPYRIGHT International Business Machines Corp., 2007
# Reservados todos los derechos * Materiales bajo licencia - Propiedad de IBM

-------------------------------------------------------------
Herramienta IBM Support Assistant Lite
-------------------------------------------------------------

Descripci�n
---------------

La herramienta IBM Support Assistant Lite suministra la recogida de datos autom�tica para productos IBM. La herramienta est� preconfigurada para localizar
datos de diagn�stico importantes en el sistema y copiarlos en un archivo de Colector. Un ejemplo de datos de diagn�stico es un archivo de anotaciones generado por el producto IBM
que contenga un historial detallado de los eventos ocurridos durante la operaci�n del producto. Un archivo de este tipo puede ser de utilidad para determinar la naturaleza y la causa de un problema de software.
Otros ejemplos de datos de diagn�stico son los archivos de inicializaci�n, los archivos de configuraci�n, la versi�n del sistema operativo, el espacio de disco y las conexiones de red.
La herramienta puede ejecutarse en modalidad de GUI o en modalidad de consola de l�nea de mandatos.
La modalidad de consola ofrece un control de l�nea de mandatos de los scripts de recogida de IBM Support Assistant Lite.  La herramienta incluye varias caracter�sticas que facilitan la interacci�n con
la misma en modalidad de consola, incluida una que permite registrar las respuestas desde una sesi�n
en modalidad de consola en un archivo y utilizarlo para controlar las ejecuciones subsiguientes del
mismo script de recogida.

Instalaci�n y utilizaci�n de la herramienta
---------------------------
En la mayor�a de los casos, bastar� la secuencia de pasos siguiente para configurar la herramienta y ponerla en funcionamiento. Si detecta problemas o desea
m�s informaci�n acerca de alguno de loa pasos, puede consultar las secciones que figuran a continuaci�n de esta. 

1.	Instale la herramienta extrayendo los archivos del archivador que ha generado y transferido desde el sistema del entorno de trabajo.
 - Extraiga la herramienta en un directorio de su elecci�n.
 - Consulte las secciones que figuran a continuaci�n para obtener detalles acerca de c�mo realizar las extracciones. 

2.	Ejecute la herramienta en modalidad de GUI o en modalidad de consola de l�nea de mandatos. 
 - Siga el procedimiento descrito m�s adelante para establecer la variable de entorno JAVA_HOME. Una vez hecho esto, podr� ejecutar el script de lanzamiento.
 - Una vez iniciada la herramienta, siga las instrucciones que figuran m�s adelante para interactuar con ella al realizar una recogida. 

Instalaci�n de la herramienta
--------------------
En todos los casos, la instalaci�n de la herramienta IBM Support Assistant Lite s�lo requiere extraer los archivos del archivo .zip que ha
generado y transferido desde el sistema del entorno de trabajo. Los archivos pueden extraerse en cualquier ubicaci�n del sistema de archivos del sistema donde vaya a ejecutar la herramienta. 
Esta operaci�n crear� un subdirectorio ISALite bajo el directorio destino. 


Utilizaci�n de la herramienta
-----------
Establecer la variable de entorno JAVA_HOME
Independientemente de si va a utilizar la herramienta IBM Support Assistant Lite en modalidad de GUI o en modalidad de consola de l�nea de mandatos, utilizar�
el mismo procedimiento para iniciarla: invocar� el script de lanzamiento adecuado desde una l�nea de mandatos. En el caso de un sistema Windows, este scripts de lanzamiento
son archivos por lotes. En otros entornos, son scripts de shell. 

Dado que la herramienta se implementa como aplicaci�n Java, esa necesario poder localizar Java para poder iniciar la herramienta. Si Java no est�
disponible en la variable PATH, deber� establecer manualmente la variable de entorno JAVA_HOME.
La herramienta IBM Support Assistant Lite requiere un JRE del nivel 1.4.2 o posterior, por lo que primero debe asegurarse de que tener instalado un JRE adecuado
en el sistema en el que va a ejecutarse la herramienta. En caso afirmativo, deber� emitir un mandato espec�fico del sistema operativo para establecer la variable JAVA_HOME
para que se�ale a este JRE. La JVM y el JDK de Microsoft no est�n soportados. 

Por ejemplo, si en una plataforma Windows tiene instalado jre1.4.2 en
c:\jre1.4.2, establecer� JAVA_HOME mediante el mandato siguiente:

SET JAVA_HOME=c:\jre1.4.2
NOTA: no utilice comillas en el valor del mandato SET, aunque el	valor contenga espacios en blanco.

En una plataforma Linux, AIX, Solaris o iSeries, si tiene el JRE	instalado en
/opt/jre142, establecer� JAVA_HOME mediante el mandato	siguiente:

export JAVA_HOME=/opt/jre142


Iniciar la herramienta en modalidad de GUI de Swing
------------------------------------
Deber� emitir el script de lanzamiento siguiente: 

- Para el entorno Windows, el script runISALite.bat del directorio \ISALite de la herramienta.
- Para los entornos Linux, AIX, HP-UX y Solaris, el script runISALite.sh del directorio /ISALite de la herramienta. Aseg�rese de que
el script runISALite.sh tenga permiso de ejecuci�n; puede utilizar el
mandato siguiente para otorgar permiso de ejecuci�n al archivo: chmod 755 runISALite.sh

La modalidad de GUI no est� soportada en los entornos iSeries y zSeries: consulte la pr�xima secci�n
para obtener informaci�n acerca de c�mo iniciar la herramienta en modalidad de consola de l�nea de
mandatos en iSeries y zSeries. 

Iniciar la herramienta en modalidad de consola de l�nea de mandatos
-----------------------------------------------
Deber� emitir el script de lanzamiento siguiente: 

- Para el entorno Windows, el script runISALiteConsole.bat del directorio \ISALite de la herramienta.
- Para los entornos Linux, AIX, HP-UX y Solaris, el script runISALiteConsole.sh del directorio /ISALite de la herramienta. Aseg�rese de que
el script runISALiteConsole.sh tenga permiso de ejecuci�n; puede utilizar el
mandato siguiente para otorgar permiso de ejecuci�n al archivo: chmod 755 runISALiteConsole.sh. Aseg�rese de que
el script runISALiteConsole_iseries.sh tenga permiso de ejecuci�n; puede utilizar el
mandato siguiente para otorgar permiso de ejecuci�n al archivo: chmod 755 runISALiteConsole_iseries.sh. Aseg�rese de que
el script runISALiteConsole_zseries.sh tenga permiso de ejecuci�n; puede utilizar el
mandato siguiente para otorgar permiso de ejecuci�n al archivo: chmod 755 runISALiteConsole_zseries.sh.
	
Interactuar con la herramienta
---------------------------
Tanto en la modalidad de GUI como en la de consola de l�nea de mandatos, se le solicitar� que configure varios campos, como por ejemplo el nombre del archivo zip de recogida de datos y
otra informaci�n espec�fica del producto. Despu�s de eso, seleccionar� la opci�n de problema y se realizar� la recogida de datos.

				Si IBM Support Assistant Lite se ejecuta en modalidad de texto, no hay listas de selecci�n ni campos
				de entrada para la informaci�n de entrada del usuario. En lugar de ello, se presentan opciones disponibles en forma
				de listas numeradas, y el usuario especifica el n�mero de la selecci�n seguido de la tecla Intro. Los campos de entrada
				se transforman en solicitudes, en las que se especifica la respuesta y se pulsa Intro. Cuando la recogida de datos ha
				finalizado, la salida es otro archivo ZIP que puede transferirse de nuevo manualmente a la m�quina en la que est�
				instalado IBM Support Assistant Workbench. Desde all�, el archivo ZIP de salida puede enviarse a IBM Support o
				examinarse localmente, igual que otras recogidas realizadas en IBM Support Assistant Workbench.

Para detener la herramienta de recogida, especifique quit en la modalidad de texto o pulse el bot�n Salir en la modalidad de GUI.

*NOTA: Lea la gu�a del usuario de IBM Support Assistant para obtener m�s detalles.

