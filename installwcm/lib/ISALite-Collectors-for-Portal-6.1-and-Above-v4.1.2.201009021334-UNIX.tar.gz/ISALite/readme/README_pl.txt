# (C) COPYRIGHT International Business Machines Corp. 2007
# Wszelkie prawa zastrze�one * Materia�y licencjonowane - w�asno�� IBM

-------------------------------------------------------------
Narz�dzie IBM Support Assistant Lite
-------------------------------------------------------------

Opis
---------------

Narz�dzie IBM Support Assistant Lite udost�pnia automatyczne gromadzenie danych dla produkt�w IBM. Konfiguracja fabryczna tego narz�dzia umo�liwia odnajdywanie istotnych danych
diagnostycznych na u�ywanym systemie komputerowym i kopiowanie ich do pliku modu�u gromadz�cego dane. Przyk�adem
danych diagnostycznych jest plik dziennika wygenerowany przez produkt IBM, zawieraj�cy szczeg�ow�
histori� zdarze�, kt�re mia�y miejsce w trakcie jego dzia�ania. Plik taki mo�e by� bardzo pomocny przy
okre�laniu rodzaju i przyczyny b��du oprogramowania.
Inne przyk�ady danych diagnostycznych to: pliki inicjuj�ce, pliki konfiguracyjne, wersja systemu operacyjnego,
miejsce na dysku i po��czenia sieciowe.
Narz�dzie mo�na uruchamia� w trybie GUI lub w trybie konsoli wiersza komend.
Tryb konsoli umo�liwia sterowanie skryptami gromadzenia danych programu IBM Support Assistant Lite z wiersza komend. Narz�dzie obejmuje wiele opcji pomagaj�cych w interakcji z nim w trybie konsoli, mi�dzy innymi opcj� umo�liwiaj�c� rejestrowanie odpowiedzi z sesji trybu konsoli w pliku, a nast�pnie dalsze uruchomienia tego samego skryptu gromadzenia danych za pomoc� tego pliku. 

Instalacja i u�ywanie narz�dzia
---------------------------
W wi�kszo�ci przypadk�w uruchomienie narz�dzia wymaga wykonania nast�puj�cych czynno�ci. W przypadku problem�w lub aby uzyska� wi�cej informacji na temat kt�rego� z tych krok�w, mo�na odwo�a� si� do poni�szych sekcji. 

1.	Zainstaluj narz�dzie, wyodr�bniaj�c pliki z wygenerowanego i przes�anego z systemu Workbench archiwum.
 - Wyodr�bnij narz�dzie w dowolnie wybranych katalogu.
 - W poni�szych sekcjach opisano szczeg�y wyodr�bniania. 

2.	Uruchom narz�dzie w trybie GUI lub w trybie konsoli wiersza komend. 
 - Wykonaj opisan� poni�ej procedur� ustawiania zmiennej �rodowiskowej JAVA_HOME. Nast�pnie mo�na wykona� skrypt uruchamiania.
 - Po uruchomieniu narz�dzia wykonaj poni�sze instrukcje interakcji z nim w trakcie gromadzenia danych. 

Instalowanie narz�dzia
--------------------
We wszystkich przypadkach instalacja narz�dzia IBM Support Assistant Lite sprowadza si� do wyodr�bnienia plik�w z archiwum .zip wygenerowanego w systemie Workbench i przes�anego z niego. Pliki mo�na wyodr�bni� w dowolnym miejscu systemu plik�w, w kt�rym narz�dzie b�dzie uruchamiane. Spowoduje to utworzenie podkatalogu ISALite w katalogu docelowym. 


Korzystanie z narz�dzia
-----------
Ustawienie zmiennej �rodowiskowej JAVA_HOME
Niezale�nie od tego, czy narz�dzie IBM Support Assistant Lite b�dzie u�ywane w trybie GUI, czy w trybie wiersza komend konsoli, uruchamia si� je tak samo: nale�y wywo�a� odpowiedni skrypt uruchomieniowy z wiersza komend. W systemie Windows skrypty uruchomieniowe s� plikami wsadowymi. W innych �rodowiskach s� one skryptami pow�oki. 

Poniewa� narz�dzie jest zaimplementowane jako aplikacja j�zyka Java, przed jego uruchomieniem nale�y znale�� interpreter tego j�zyka. Je�li interpreter j�zyka Java jest niedost�pny w �cie�ce okre�lonej przez zmienn� �rodowiskow� PATH, trzeba ustawi� zmienn� �rodowiskow� JAVA_HOME r�cznie.
Narz�dzie IBM Support Assistant Lite wymaga �rodowiska JRE na poziomie 1.4.2 lub nowszego, dlatego nale�y najpierw upewni� si�, �e odpowiednie �rodowisko JRE jest zainstalowane w systemie, na kt�rym narz�dzie b�dzie dzia�a�. Je�li tak, to trzeba uruchomi� komend� systemu operacyjnego tak, aby zmienna JAVA_HOME wskazywa�a na to �rodowisko JRE. Oprogramowanie Microsoft JVM/JDK nie jest obs�ugiwane. 

Na przyk�ad, je�li na platformie Windows �rodowisko jre 1.4.2 jest zainstalowane
w katalogu c:\jre1.4.2, nale�y ustawi� zmienn� JAVA_HOME przy u�yciu nast�puj�cej komendy:

SET JAVA_HOME=c:\jre1.4.2
UWAGA: w argumencie komendy SET nie nale�y stosowa� znak�w cudzys�owu, nawet je�li argument ten zawiera bia�e znaki.

Na platformach Linux, AIX, Solaris lub iSeries, je�li �rodowisko JRE jest zainstalowane
w katalogu /opt/jre142, nale�y ustawi� zmienn� JAVA_HOME przy u�yciu nast�puj�cej komendy:

export JAVA_HOME=/opt/jre142


Uruchamianie narz�dzia w trybie Swing GUI
------------------------------------
Nale�y uruchomi� nast�puj�cy skrypt uruchomieniowy: 

- W �rodowisku Windows b�dzie to skrypt runISALite.bat w katalogu \ISALite narz�dzia.
- W �rodowiskach Linux, AIX, HP-UX i Solaris b�dzie to skrypt runISALite.sh w katalogu /ISALite narz�dzia. Sprawd�, czy skrypt runISALite.sh ma uprawnienie do wykonania; mo�na u�y� nast�puj�cej komendy, aby nada� plikowi to uprawnienie: chmod 755 runISALite.sh

Tryb GUI nie jest obs�ugiwany w �rodowiskach iSeries i zSeries: w dalszej sekcji opisano, jak uruchamia� narz�dzie w trybie wiersza komend konsoli w systemach iSeries i zSeries. 

Uruchamianie narz�dzia w trybie wiersza komend konsoli
-----------------------------------------------
Nale�y uruchomi� nast�puj�cy skrypt uruchomieniowy: 

- W �rodowisku Windows b�dzie to skrypt runISALiteConsole.bat w katalogu \ISALite narz�dzia.
- W �rodowiskach Linux, AIX, HP-UX i Solaris b�dzie to skrypt runISALiteConsole.sh w katalogu /ISALite narz�dzia. Sprawd�, czy skrypt runISALiteConsole.sh ma uprawnienie do wykonania; mo�na u�y� nast�puj�cej komendy, aby nada� plikowi to uprawnienie: chmod 755 runISALiteConsole.sh
- W �rodowisku iSeries b�dzie to skrypt runISALiteConsole_iseries.sh w katalogu /ISALite narz�dzia. Sprawd�, czy skrypt runISALiteConsole_iseries.sh ma uprawnienie do wykonania; mo�na u�y� nast�puj�cej komendy, aby nada� plikowi to uprawnienie: chmod 755 runISALiteConsole_iseries.sh
- W �rodowisku zSeries b�dzie to skrypt runISALiteConsole_zseries.sh w katalogu /ISALite narz�dzia. Sprawd�, czy skrypt runISALiteConsole_zseries.sh	ma uprawnienie do wykonania; mo�na u�y� nast�puj�cej komendy, aby nada� plikowi to uprawnienie: chmod 755 runISALiteConsole_zseries.sh	
	
Interakcje z narz�dziem
---------------------------
W obu trybach: GUI i wiersza komend konsoli trzeba b�dzie skonfigurowa� pewne pola, na przyk�ad nazw� pliku zip z kolekcj� i inne informacje dotycz�ce konkretnego produktu. Nast�pnie nale�y wybra� opcj� problemu, co powoduje rozpocz�cie operacji gromadzenia danych.

Kiedy program IBM Support Assistant Lite dzia�a w trybie tekstowym, u�ytkownik nie ma do dyspozycji list wyboru ani p�l wprowadzania.
Zamiast nich dost�pne opcj� s� reprezentowane przez numerowane listy. U�ytkownik musi wprowadzi� numer wybranej opcji, a nast�pnie nacisn�� klawisz Enter. Zamiast p�l wej�ciowych
				stosowane s� podpowiedzi. U�ytkownik musi wpisa� odpowied� i nacisn�� klawisz Enter. Po zako�czeniu gromadzenia danych
				dane wyj�ciowe zapisywane s� w postaci pliku ZIP, kt�ry mo�na r�cznie przes�a� z powrotem na komputer, na kt�rym
				zainstalowane jest �rodowisko robocze programu IBM Support Assistant. Stamt�d plik wyj�ciowy ZIP mo�na wys�a� do dzia�u wsparcia IBM lub sprawdzi� lokalnie,
				tak samo, jak w przypadku innych danych zgromadzonych w �rodowisku roboczym programu IBM Support Assistant.

Aby zatrzyma� narz�dzie gromadzenia, w trybie tekstowym wpisz quit lub naci�nij przycisk Wyj�cie w trybie GUI. 

*UWAGA: Dalsze szczeg�y zawiera podr�cznik u�ytkownika programu IBM Support Assistant. 

