# (C) COPYRIGHT International Business Machines Corp., 2007
# Todos os Direitos Reservados * Materiais Licenciados - Propriedade da IBM

-------------------------------------------------------------
Ferramenta IBM Support Assistant Lite
-------------------------------------------------------------

Descri��o
---------------

A Ferramenta IBM Support Assistant Lite fornece coleta de dados autom�tica para produtos IBM. A ferramenta � pr�-configurada para localizar importantes
dados de diagn�stico em seu sistema de computador e copi�-los para um arquivo do Coletor. Um exemplo de dados de diagn�stico � um arquivo de log gerado por seu produto IBM
que cont�m um hist�rico detalhado de eventos que ocorrem durante o funcionamento do produto. Este arquivo pode ser �til na determina��o da natureza e causa de um problema de software.
Outros exemplos de dados de diagn�stico incluem arquivos de inicializa��o, arquivos de configura��o, vers�o do sistema operacional, espa�o em disco e conex�es de rede. A ferramenta pode ser executada no modo da GUI ou em um modo do console de linha de comandos.
O modo do console fornece controle da linha de comandos dos scripts de coleta do IBM Support Assistant Lite.
A ferramenta inclui diversos recursos para auxili�-lo quando voc� interage com ela no modo do console, incluindo um que permite registrar suas respostas de uma sess�o do modo do console em um arquivo e, em seguida, usar o arquivo para executar execu��es subsequentes do mesmo script de coleta.


Instala��o e Uso da Ferramenta
---------------------------
Na maioria dos casos, a sequ�ncia das etapas a seguir ajudar�-lo a ativar e executar a ferramenta. Se tiver problemas ou se precisar de informa��es adicionais sobre qualquer uma dessas etapas, pode consultar as se��es abaixo que seguem esta.


1.	Instale a ferramenta extraindo os arquivos do arquivo archive gerado e transferido a partir do sistema do Ambiente de Trabalho.
 - Extraia a ferramenta para qualquer diret�rio escolhido.
 - Consulte as se��es abaixo para obter detalhes sobre como executar as extra��es. 

2.	Execute a ferramenta no modo da GUI ou no modo do console da linha de comandos. 
 - Siga o procedimento descrito abaixo para configurar a vari�vel de ambiente JAVA_HOME. Depois de fazer isso, pode, ent�o, executar o script de ativa��o.
 - Depois de iniciar a ferramenta, siga as instru��es abaixo para interagir com ela � medida que a mesma executa a coleta. 

Instalando a Ferramenta
--------------------
Em todos os casos, a instala��o da ferramenta IBM Support Assistant Lite � simplesmente uma quest�o de extra��o de arquivos do arquivo .zip arquivado gerado e transferido do sistema do Ambiente de Trabalho. Os arquivos podem ser extra�dos para qualquer local do sistema de arquivos escolhido no sistema onde voc� estar� executando a ferramenta. 
Isso criar� um subdiret�rio ISALite sob seu diret�rio de destino. 


Uso da Ferramenta
-----------
Configurando a Vari�vel de Ambiente JAVA_HOME
Independentemente de se voc� estar� usando a ferramenta IBM Support Assistant Lite no modo da GUI ou no modo do console da linha de comandos, voc� usa o mesmo procedimento para inici�-la: chama o script de ativa��o apropriado a partir de uma linha de comandos. No caso de um sistema Windows, esses scripts de ativa��o s�o arquivos em lote.
Para os outros ambientes, eles s�o scripts de shell. 

Como a ferramenta � implementada como um aplicativo Java, � necess�rio que Java possa ser localizado antes de a ferramenta ser iniciada. Se Java n�o estiver dispon�vel em PATH, ser� necess�rio configurar a vari�vel de ambiente JAVA_HOME manualmente.
A ferramenta IBM Support Assistant Lite requer um JRE no n�vel 1.4.2 ou superior, portanto, voc� deve primeiro assegurar que um JRE adequado seja instalado no sistema onde a ferramenta estar� em execu��o.
Se estiver, ent�o, ser� necess�rio emitir um comando espec�fico do sistema operacional para configurar a vari�vel JAVA_HOME para apontar para esse JRE.
Microsoft
JVM/JDK n�o � suportado.

Por exemplo, se em uma plataforma Windows voc� tiver o jre1.4.2 instalado em
c:\jre1.4.2, configure JAVA_HOME utilizando o seguinte comando: 

SET JAVA_HOME=c:\jre1.4.2
NOTA: N�o utilize aspas no valor do comando SET, mesmo que seu valor tenha espa�os em branco. 

Em uma plataforma Linux, AIX, Solaris ou iSeries, se voc� tiver o JRE instalado em
/opt/jre142, configure JAVA_HOME utilizando o seguinte comando: 

export JAVA_HOME=/opt/jre142


Iniciando a Ferramenta no Modo da GUI Swing
------------------------------------
Ser� necess�rio emitir o seguinte script de ativa��o: 

- Para o ambiente do Windows, ser� o script runISALite.bat no diret�rio \ISALite da ferramenta.
- Para os ambientes Linux, AIX, HP-UX e Solaris, ser� o script runISALite.sh no diret�rio /ISALite da ferramenta. Certifique-se de que o script
runISALite.sh tenha permiss�o de execu��o; � poss�vel usar o seguinte comando para dar ao arquivo permiss�o de execu��o: chmod 755 runISALite.sh

O modo da GUI n�o � suportado nos ambientes iSeries e zSeries: consulte a se��o que segue esta imediatamente para obter informa��es sobre como iniciar a ferramenta no modo do console da linha de comandos no iSeries e zSeries. 

Iniciando a Ferramenta no Modo do Console da Linha de Comandos
-----------------------------------------------
Ser� necess�rio emitir o seguinte script de ativa��o:

- Para o ambiente do Windows, ser� o script runISALiteConsole.bat no diret�rio \ISALite da ferramenta.
- Para os ambientes Linux, AIX, HP-UX e Solaris, ser� o script runISALiteConsole.sh no diret�rio /ISALite da ferramenta. Certifique-se de que o script
runISALiteConsole.sh tenha permiss�o de execu��o; o comando a seguir pode ser usado para dar ao arquivo permiss�o de execu��o: chmod 755 runISALiteConsole.sh
- Para o ambiente iSeries, ser� o script runISALiteConsole_iseries.sh no diret�rio /ISALite da ferramenta. Certifique-se de que o script
runISALiteConsole_iseries.sh tenha permiss�o de execu��o; o comando a seguir pode ser usado para dar ao arquivo permiss�o de execu��o: chmod 755 runISALiteConsole_iseries.sh
- Para o ambiente zSeries, ser� o script runISALiteConsole_zseries.sh no diret�rio /ISALite da ferramenta. Certifique-se de que o script
runISALiteConsole_zseries.sh tenha permiss�o de execu��o; o comando a seguir pode ser usado para dar ao arquivo permiss�o de execu��o: chmod 755 runISALiteConsole_zseries.sh	
	
Interagindo com a Ferramenta
---------------------------
Para o modo da GUI e do console da linha de comandos, ser� solicitado que voc� configure diversos campos, como o nome do arquivo zip de coleta de dados e qualquer outra informa��o espec�fica do produto.
Depois disso, voc� seleciona a op��o do problema e a coleta de dados � desempenhada. 

Quando o IBM Support Assistant Lite � executado no modo de texto, n�o h� listas de sele��o nem campos de entrada para entrada do usu�rio.
Em vez disso, as op��es dispon�veis s�o apresentadas como listas numeradas
				e voc� digita o n�mero de sua sele��o seguido pela tecla Enter. Os campos de entrada s�o transformados
				em prompts, nos quais voc� digita sua resposta e pressiona Enter. Quando a coleta de dados estiver conclu�da,
				a sa�da ser� outro arquivo ZIP que pode ser manualmente transferida de volta para a m�quina na qual o IBM Support
				Assistant Workbench est� instalado. De l�, o arquivo ZIP de sa�da pode ser enviado para o Suporte IBM ou examinado
				localmente, da mesma forma que com outras coletas desempenhadas no IBM Support Assistant Workbench.


Para parar a ferramenta coletora, digite quit no modo de texto ou clique no bot�o Encerrar no modo da GUI. 

*NOTA: Leia o guia do usu�rio do IBM Support Assistant para obter detalhes adicionais. 

