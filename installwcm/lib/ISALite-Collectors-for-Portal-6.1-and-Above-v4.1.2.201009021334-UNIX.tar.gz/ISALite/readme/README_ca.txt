# (C) COPYRIGHT International Business Machines Corp., 2007
# Reservats tots els drets * Materials sota llic�ncia - Propietat d'IBM

-------------------------------------------------------------
Eina IBM Support Assistant Lite
-------------------------------------------------------------

Descripci�
---------------

L'eina IBM Support Assistant Lite proporciona recollides de dades autom�tiques per a productes IBM. L'eina est� preconfigurada per trobar dades importants de diagn�stic en el vostre sistema i copiar-les en un fitxer del col�lector. Un exemple de dades de diagn�stic �s un fitxer d'anotacions generat pel producte d'IBM que cont� un historial detallat de les incid�ncies que es produeixen durant el funcionament del producte. Un fitxer com aquest pot ser �til en la determinaci� de la natura i la causa d'un problema de programari.
Altres exemples de dades de diagn�stic s�n els fitxers d'inicialitzaci�, els fitxer de configuraci�, la versi� del sistema operatiu, l'espai en disc i les connexions de xarxa.
L'eina es pot executar en modalitat GUI o en modalitat de l�nia d'ordres amb consola.
La modalitat amb consola proporciona control mitjan�ant la l�nia d'ordres de l'script de recollida d'IBM Support Assistant Lite.  L'eina inclou diverses funcions per facilitar la interacci� amb la modalitat amb consola, inclosa una que permet enregistrar les respostes des d'una sessi� de modalitat amb consola en un fitxer i, a continuaci�, utilitzar el fitxer per execucions posteriors del mateix script de recollida.


Instal�laci� i �s de l'eina
---------------------------
En la majoria de casos, la seq��ncia de passos seg�ent ser� suficient perqu� l'eina funcioni correctament. Si sorgeixen problemes, o si voleu obtenir m�s informaci� sobre algun dels passos, podeu consultar les seccions que es mostren m�s endavant.


1.	Instal�leu l'eina extraient els fitxers del fitxer d'arxiu que heu generat i transferint del sistema de Workbench.
 - Extraieu l'eina en qualsevol directori que escolliu.
- Vegeu les seccions que es mostren m�s endavant per obtenir detalls sobre com realitzar les extraccions.

2.	Executeu l'eina en modalitat GUI o en modalitat de l�nia d'ordres amb consola.

 - Seguiu el procediment descrit a continuaci� per establir la variable d'entorn JAVA_HOME. Un cop fet aix�, podeu executar l'script d'inici.
- Quan s'hagi iniciar l'eina, seguiu les instruccions que es mostren a continuaci� per interactuar-hi mentre realitza una recollida.

Instal�laci� de l'eina
--------------------
En tots els casos, la instal�laci� de l'eina IBM Support Assistant Lite simplement consisteix en extreure els fitxers del fitxer .zip arxivat que s'ha generat i transferit al sistema de Workbench.
Els fitxers es poden extreure en qualsevol ubicaci� del sistema que escolliu on s'executar� l'eina.
Es crear� un subdirectori ISALite sota el directori de destinaci�.



�s de l'eina
-----------
Establiment de la variable d'entorn JAVA_HOME
Independentment de si utilitzareu l'eina IBM Support Assistant Lite en modalitat GUI o en modalitat l�nia d'ordres amb consola, heu d'utilitzar el mateix procediment per iniciar-la: invocar l'script d'inici apropiat des d'una l�nia d'ordres. En cas de sistema Windows, aquests scripts d'inici s�n fitxers per lots.  Per altres sistemes, s�n scripts d'int�rpret d'ordres.

At�s que l'eina s'implementa com a aplicaci� Java, �s necessari localitzar Java abans que s'inici� l'eina. Si Java no est� disponible al cam� d'acc�s, s'haur� d'establir la variable d'entorn JAVA_HOME manualment. L'eina IBM Support Assistant Lite necessita un JRE de nivell 1.4.2 o superior; per tant, us haureu d'assegurar que hi ha instal�lat un JRE adequat al sistema on s'executa l'eina.
Si teniu el nivell correcte instal�lat, ser� necessari emetre una ordre espec�fica de sistema operatiu per establir la variable JAVA_HOME que apunti al JRE.
La JVM i el JDK de Microsoft no estan suportats. 

Per exemple, si en una plataforma Windows teniu instal�lat jre1.4.2 a c:\jre1.4.2, haur�eu d'establir JAVA_HOME mitjan�ant l'ordre seg�ent:

SET JAVA_HOME=c:\jre1.4.2
NOTA: no utilitzeu cometes en el valor de l'ordre SET, encara que el valor tingui car�cters d'espai en blanc.

En una plataforma Linux, AIX, Solaris o iSeries, si teniu instal�lat el JRE a /opt/jre142, haur�eu d'establir JAVA_HOME mitjan�ant l'ordre seg�ent:

export JAVA_HOME=/opt/jre142


Inici de l'eina en modalitat Swing GUI
------------------------------------
Ser� necessari emetre l'script d'inici seg�ent:

- Per entorns Windows, emeteu l'script runISALite.bat al directori \ISALite de l'eina.
- Per entorns Linux, AIX, HP-UX i Solaris, emeteu l'script runISALite.sh al directori /ISALite de l'eina. Assegureu-vos que l'script runISALite.sh tingui perm�s d'execuci�; podeu utilitzar l'ordre seg�ent per atorgar el perm�s d'execuci� del fitxer: chmod 755 runISALite.sh

La modalitat GUI no se suporta en entorns iSeries i zSeries: vegeu la secci� seg�ent per obtenir informaci� sobre l'inici de l'eina en modalitat de l�nia d'ordres amb consola a iSeries i zSeries. 

Inici de l'eina en modalitat de l�nia d'ordres amb consola
-----------------------------------------------
Ser� necessari que emeteu l'script d'inici seg�ent:

- Per entorns Windows, emeteu l'script runISALiteConsole.bat al directori \ISALite de l'eina.
- Per entorns Linux, AIX, HP-UX i Solaris, emeteu l'script runISALiteConsole.sh al directori /ISALite de l'eina. Assegureu-vos que l'script runISALiteConsole.sh tingui perm�s d'execuci�; podeu utilitzar l'ordre seg�ent per atorgar el perm�s d'execuci� del fitxer: chmod 755 runISALiteConsole.sh Assegureu-vos que l'script runISALiteConsole_iseries.sh tingui perm�s d'execuci�; podeu utilitzar l'ordre seg�ent per atorgar el perm�s d'execuci� del fitxer: chmod 755 runISALiteConsole_iseries.sh Assegureu-vos que l'script runISALiteConsole_zseries.sh tingui perm�s d'execuci�; podeu utilitzar l'ordre seg�ent per atorgar el perm�s d'execuci� del fitxer: chmod 755 runISALiteConsole_zseries.sh	
	
Interacci� amb l'eina
---------------------------
Tant per la modalitat GUI com per la modalitat amb l�nia d'ordres de consola, se us sol�licitar� que configureu certs camps, com ara el nom del fitxer ZIP de sortida de la recollida de dades i altra informaci� espec�fica del producte.  Despr�s, seleccioneu l'opci� de problema perqu� s'efectu� la recollida de dades.

Quan s'executa IBM Support Assistant Lite en modalitat de text, no hi ha llistes de selecci� ni camps d'entrada per l'usuari.
En comptes, les opcions disponibles es presenten com a llistes numerades on cal entrar el n�mero de selecci� seguit per la tecla Retorn. Els camps d'entrada es transformen en sol�licituds en les quals s'especifica una resposta i es prem la tecla Retorn. En acabar la recollida de dades, la sortida ser� un altre fitxer ZIP que es pot tornar a transferir manualment a la m�quina on estigui instal�lat IBM Support Assistant Workbench. Des d'all�, el fitxer ZIP de sortida es pot enviar al servei de suport d'IBM Support o b� es pot examinar localment, d'igual manera que succeeix amb altres recollides efectuades a IBM Support Assistant Workbench.

Per aturar l'eina del col�lector, escriviu quit en modalitat de text o feu clic al bot� Surt en modalitat GUI.

*NOTA: Vegeu la guia del usuari d'IBM Support Assistant per obtenir m�s informaci�.

