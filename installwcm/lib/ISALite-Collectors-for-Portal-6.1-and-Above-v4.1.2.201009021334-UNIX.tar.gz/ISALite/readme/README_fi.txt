# (C) COPYRIGHT International Business Machines Corp., 2007
# Kaikki oikeudet pid�tet��n * Lisensoitua aineistoa - IBM:n omaisuutta

-------------------------------------------------------------
IBM Support Assistant-sovelluksen tiedonker�inty�kalu
-------------------------------------------------------------

Kuvaus
---------------

IBM Support Assistant (ISA) -sovelluksen tiedonker�inty�kalulla voit ker�t� IBM-tuotteita koskevia tietoja automaattisesti. Ty�kalu on m��ritetty valmiiksi paikantamaan tietokonej�rjestelm�ss�si olevia t�rkeit� vianm��ritystietoja ja kopioimaan ne tiedonker�intiedostoon. Esimerkkin� vianm��ritystiedoista on IBM-tuotteen luoma lokitiedosto, joka sis�lt�� yksityiskohtaiset tiedot tuotteen toiminnan aikaisista tapahtumista. T�llaisesta tiedostosta voi olla hy�ty� selvitett�ess� ohjelmisto-ongelman luonnetta ja syyt�.
Muita esimerkkej� vianm��ritystiedoista ovat alustustiedostot, kokoonpanotiedostot, k�ytt�j�rjestelm�n versio, levytila ja verkkoyhteydet. 

Asennus/k�ytt�
----------------------
JAVA_HOME-muuttujan M��RITYS:
Jotta ty�kalu toimisi oikein, varmista, ett� JAVA_HOME-ymp�rist�muuttujan
arvoksi on m��ritetty v�hint��n JRE-versio 1.4.2.
Jos esimerkiksi JRE 1.4.2 -ymp�rist� on asennettu Windows-k�ytt�j�rjestelm�n
hakemistoon c:\jre1.4.2, m��rit� JAVA_HOME-ymp�rist�muuttuja seuraavalla
komennolla:

SET JAVA_HOME=c:\jre1.4.2
HUOMAUTUS: �l� k�yt� SET-komennossa lainausmerkkej�, vaikka arvossa olisi tyhj�merkkej�.

Jos k�yt�t Linux-, AIX-, Solaris- tai iSeries-k�ytt�j�rjestelm�� ja JRE-ymp�rist� on
asennettu hakemistoon /opt/jre142, voit m��ritt�� JAVA_HOME-ymp�rist�muuttujan arvon
seuraavalla komennolla:

export JAVA_HOME=/opt/jre142

Windows-k�ytt�j�rjestelm�t:

	1) Pura .zip-arkistotiedosto.
	2) Siirry hakemistoon, johon purit zip-tiedoston.
	3) Aja startcollector.bat-tiedosto.

Unix-k�ytt�j�rjestelm�t:

	1) Pura .zip-arkistotiedosto.
	2) Siirry hakemistoon, johon purit zip-tiedoston.
	3) Varmista, ett� kaikilla komentotulkin komentotiedostoilla on suoritusoikeudet. Voit my�nt�� suoritusoikeuden tiedostolle seuraavalla komennolla: chmod -R 755 `find . -name '*.sh'`
	4) Aja ./startcollector.sh-tiedosto.
	
iSeries-k�ytt�j�rjestelm�t:
	1) Pura .zip-arkistotiedosto.
	2) Siirry hakemistoon, johon purit zip-tiedoston.
	3) Varmista, ett� kaikilla komentotulkin komentotiedostoilla on suoritusoikeudet. Voit my�nt�� suoritusoikeuden tiedostolle seuraavalla komennolla: chmod -R 755 `find . -name '*.sh'`
	4) Aja ./startcollector.sh-tiedosto.
	
zSeries-k�ytt�j�rjestelm�t:
	1) Pura .zip-arkistotiedosto.
	2) Siirry hakemistoon, johon purit zip-tiedoston.
	3) Varmista, ett� kaikilla komentotulkin komentotiedostoilla on suoritusoikeudet. Voit my�nt�� suoritusoikeuden tiedostolle seuraavalla komennolla: chmod -R 755 `find . -name '*.sh'`
	4) Aja ./startcollector_zseries.sh-tiedosto. 

------------------------------------------------------------------------------------------------------------------------------------------------------------------------
**HUOMAUTUS: Ty�kalu edellytt��, ett� j�rjestelm��n on asennettu JRE-ymp�rist�n versio 1.4.2 tai uudempi versio. 
Microsoft JVM/JDK ei ole tuettu. 
------------------------------------------------------------------------------------------------------------------------------------------------------------------------

Ennen tiedonkeruuta on m��ritett�v� useita kentti�, kuten tiedonkeruun zip-tiedoston nimi ja muita tuotekohtaisia tietoja. 
Valitse t�m�n j�lkeen ongelmavaihtoehto. Tiedonkeruu alkaa. 

Jos haluat lopettaa tiedonker�imen k�yt�n, kirjoita quit (lopeta).

*HUOMAUTUS: Lis�tietoja on IBM Support Assistant -sovelluksen version 4 k�ytt�oppaassa.

