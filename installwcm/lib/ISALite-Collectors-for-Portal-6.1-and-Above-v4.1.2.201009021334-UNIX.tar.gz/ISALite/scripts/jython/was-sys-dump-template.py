jvm = AdminControl.queryNames('node=' + $nodeName + ',process=' + $serverName + ',type=JVM,*')
AdminControl.invoke($jvm, 'generateSystemDump')
