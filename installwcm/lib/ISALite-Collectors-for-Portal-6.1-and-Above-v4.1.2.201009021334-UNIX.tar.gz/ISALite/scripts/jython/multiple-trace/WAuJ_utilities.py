#---------------------------------------------------------------------
#    Name: WAuJ_utilities
#    From: WebSphere Application Server Administration using Jython
#      By: Robert A. (Bob) Gibson [rag], Arthur Kevin McGrath, Noel J. Bergman
#    ISBN: 0-137-00952-6
#    Role: Module used to contain some useful routines
#    Note: Depends upon availability of WSAS scripting objects via sys.modules
#          See WAuJ.py
#   Usage: import WAuJ_utilities as WAuJ
#          
# History:
#   when    who ver  what
# --------  --- ---- ----------
# 10/06/04  rag 0.23 Add - findTypes()
# 10/05/28  rag 0.22 Fix - displayDict()         -> 0.5
# 10/05/24  rag 0.21 Add - configurable()
# 10/05/19  rag 0.20 Fix - scopedWSASvariables() -> 0.2
#                    Fix - configIdFilter()      -> 0.1
#                    Fix - WSASvariables()       -> 0.2
# 10/05/13  rag 0.19 Fix - displayDict() display double quoted "list" values correctly
# 10/05/12  rag 0.18 Add - displayDict() function to better display "list" values
# 10/04/22  rag 0.17 Add - Change docstrings to include routine signatures,
#                          add findNamedConfigType(), getEndPointName(),
#                          getEndPoints(), getPort(), getPorts()
# 10/04/19  rag 0.16 Fix - unravel() - check for '[]' (empty string)
# 10/04/18  rag 0.15 Add - scopedWSASvariables(), WSASvariables() & unravel()
# 10/04/17  rag 0.14 Add - Example use for configIdFilter()
# 10/04/16  rag 0.13 Add - Add configInfoAsDict(), cellInfo(), nodeInfo(),
#                          memberInfo(), serverInfo(), configIdFilter().
#                          Rewrite clusterInfo() using configInfoAsDict().
# 10/04/15  rag 0.12 Fix - Add callerName docstring
# 10/04/08  rag 0.11 Fix - displayDict() to not die if the dictionary is empty
# 10/01/27  rag 0.10 Add - callerName()
# 09/12/07  rag 0.9  Fix - brackGroups() - correctly handle nested brackets
# 09/11/15  rag 0.8  Fix - stringListAsList()
#                    Add - docstring for brackGroups(), nvListAsDict(),
#                          nvTextListAsDict(), stringAsNestedList()
#                          stringListAsList()
#                    Add - localMode()
# 09/11/14  rag 0.7  Fix - Rewrite clusterInfo()
#                    Add - version number and lastUpdated variables
#                    Add - displayDict() optional parameter: width
#                    Add - stringListAsList()
# 09/08/18  rag 0.6  Add - bracketGroups(), nvListAsDict() &
#                          stringAsNestedList()
# 09/04/07  rag 0.5  Add - displayDict() routine
# 09/03/21  rag 0.4  Fix - corrected nvTextListAsDict() comments
# 08/12/17  rag 0.3  Add - nvTextListAsDict() routine
# 08/12/09  rag 0.2  Add - docstring for fixFileName() & Usage() routines
# 08/11/07  rag 0.1  Add - docstring
# 08/10/31  rag 0.0  New - for the book
#---------------------------------------------------------------------
'''
     From: WebSphere Application Server Administration using Jython (WAuJ)
       By: Robert A. (Bob) Gibson, Arthur Kevin McGrath, Noel J. Bergman
Published: IBM Press - Oct 2009
     ISBN: 0-137-00952-6
     Role: Provide a collection of library routines to assist with the
           Administration of a WebSphere Application Server environment.
'''

version     = '0.23'
lastUpdated = '04 June 2010'

import sys, re;              # Make these libraries available for all
 
#---------------------------------------------------------------------
# Name: bracketGroups()
# Role: Routine used to process a string containing matching bracket
#       (i.e., []), and return a list containing the string positions
#       of these bracket pairs.
# Note: A malformed input string can cause an exception.
# Example:
#   >import WAuJ_utilities as WAuJ;
#   >WAuJ.bracketGroups( '[name value][name value]' );
#   [[0, 11], [12, 23]]
#   >WAuJ.bracketGroups( '[[name value][name value]]' )
#   [[0, 25], [1, 12], [13, 24]]
# History:
#   when  ver who what
# -------- --- --- ---------------------------------------------------
# 09/12/07 0.2 rag Fix - rewrite to properly return nested list values
# 09/11/15 0.1 rag Add - docstring
# 09/08/18 0.0 rag New - Use to validate input strings containing
#                        bracketed groups.
#---------------------------------------------------------------------
def bracketGroups( string ) :
  'bracketGroup( string ) - Process a string containing matching brackets, returning a list of string positions of the matching brackets'
  result = [];                         # Build the result list as we go
  pair   = [];                         # Current pair of values - stack
  for offset in range( len( string ) ) :
    c = string[ offset ];              # Current character in string
    if c == '[' :                      # Open bracket?
      here = [ offset ];               # Yes - add a new list to result
      result.append( here );           #
      pair.append( result[ -1 ] );     #       and add a binding to pair
                                       #
    if c == ']' :                      # Closing bracket?
      here = pair.pop();               # Remove top of stack from pair
      here.append( offset );           # Append closing offset to it
                                       #
  return result;                       # Return the list of bracket pair offsets


#---------------------------------------------------------------------
# Name: callerName
# Role: Utility routine used to determine, and return the name of the
#       function that called it.
# Note: Dependent upon sys._getframe()
# History:
#   when  ver who what
# -------- --- --- ---------------------------------------------------
# 10/04/15 0.1 rag Add - docstring
# 10/01/27 0.0 rag New - See http://code.activestate.com/recipes/66062/
#---------------------------------------------------------------------
def callerName() :
  "callerName() - Returns the name of the calling routine (or '?')"
  return sys._getframe( 1 ).f_code.co_name;


#---------------------------------------------------------------------
# Name: cellInfo()
# Role: Return a dictionary having the primary key being the unique
#       cell name(s), and the values being the associated configID
#       for that cell
# Example: clusters = clusterInfo()
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/04/16 0.0 rag New - Write using configInfoAsDict()
#---------------------------------------------------------------------
def cellInfo() :
  'cellInfo() - Return a dictionary of the cell names, and their configuration IDs.'
  return configInfoAsDict( 'Cell' );


#---------------------------------------------------------------------
# Name: configIdAsDict
# Role: Utility routine used to return a dictionary of name/value
#       details from an configuration ID (configID)
# Note: Exception handler requires sys module
# History:
#   when  ver who what
# -------- --- --- ---------------------------------------------------
# 09/08/11 0.3 rag Fix - Check for & handle double quoted configIDs
# 08/12/03 0.2 rag Mod - Change "unexpected situation" message
# 08/11/04 0.1 rag Add - Add the "Name" attribute to the dictionary
# 08/10/27 0.0 rag New - insight obtained while writing the book
#---------------------------------------------------------------------
def configIdAsDict( configId ) :
  'configIdAsDict( configId ) - Given a configID, return a dictionary of the name/value components.'
  funName = callerName();              # Name of this function
  result  = {};                        # Result is a dictionary
  hier    = [];                        # Initialize to simplifiy checks
  try :                                # Be prepared for an error
    #-----------------------------------------------------------------
    # Does the specified configID match our RegExp pattern?
    # Note: mo == Match Object, if mo != None, a match was found
    #-----------------------------------------------------------------
    if ( configId[ 0 ] == '"' ) and ( configId[ -1 ] == '"' ) and ( configId.count( '"' ) == 2 ) :
      configId = configId[ 1:-1 ];
    mo = re.compile( r'^([\w ]+)\(([^|]+)\|[^)]+\)$' ).match( configId );
    if mo :
      Name = mo.group( 1 );
      hier = mo.group( 2 ).split( '/' );
    if mo and ( len( hier ) % 2 == 0 ) :
      #---------------------------------------------------------------
      # hier == Extracted config hierarchy string
      #---------------------------------------------------------------
      for i in range( 0, len( hier ), 2 ) :
        ( name, value ) = hier[ i ], hier[ i + 1 ];
        result[ name ]  = value;
      if result.has_key( 'Name' ) :
        print '''%s: Unexpected situation - "Name" attribute conflict,
  Name = "%s", Name prefix ignored: "%s"''' % ( funName, result[ 'Name' ], Name );
      else :
        result[ 'Name' ] = Name;
    else :
      print '''%(funName)s:
  Warning: The specified configId doesn\'t match the expected pattern,
           and is ignored.
  configId: "%(configId)s"''' % locals();
  except :
    ( kind, value ) = sys.exc_info()[ :2 ];
    print '''%(funName)s: Unexpected exception.\n
  Exception  type: %(kind)s
  Exception value: %(value)s''' % locals();
  return result;


#---------------------------------------------------------------------
# Name: configIdFilter()
# Role: Return either a single configID, or None.
# Note: If more than 1 configID generated, None is returned.
#       Useful for locating a specific configuration ID based upon a
#       specific sequence (pattern) of characters that the configID
#       must contain.
#
# For Example:
#       Given the configID for a specific AppServer, we know that the
#       configID of the associated Node will have the same cell and
#       node as the server.
#
#   wsadmin>import WAuJ_utilities as WAuJ
#   wsadmin>
#   wsadmin>server = AdminConfig.list( 'Server' ).splitlines()[ -1 ];
#   wsadmin>server
#   'server1(cells/ragweedCell02/nodes/ragweedNode03/servers/...)'
#   wsadmin>
#   wsadmin>cfgDict = WAuJ.configIdAsDict( server )
#   wsadmin>nodeIdPrefix = '(cells/%(cells)s/nodes/%(nodes)s|' % cfgDict
#   wsadmin>nodeIdPrefix
#   '(cells/ragweedCell02/nodes/ragweedNode03|'
#   wsadmin>node = WAuJ.configIdFilter( 'Node', nodeIdPrefix )
#   wsadmin>node
#   'ragweedNode03(cells/ragweedCell02/nodes/ragweedNode03|node.xml#Node_1)'
# 
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/05/19 0.1 rag Add - additional debug information
#                  Fix - return an empty string instead of None.
#                  Fix - handle len( result ) == 0 quietly
# 10/04/16 0.0 rag New - Useful for helping deterine "parent" configId
#---------------------------------------------------------------------
def configIdFilter( Type, pattern ) :
  'configIdFilter( Type, pattern ) - Return the (single) configID of the specified type, and filtered by the pattern.'
  result = [ x for x in AdminConfig.list( Type ).splitlines() if x.find( pattern ) > -1 ];
  if len( result ) == 1 :
    result = result[ 0 ];
  else :
    if len( result ) > 1 :
      print '%s() error: too many values (%d).' % ( callerName(), len( result ) );
      print '   Type = "%s"\npattern = "%s"' % ( Type, pattern );
    result = '';
  return result;


#---------------------------------------------------------------------
# Name: configInfoAsDict()
# Role: Return a dictionary having the primray key being the unique
#       names and the values being the associated configID for the
#       specified WebSphere Application Server type.
# Note: If no scope (configID) is provided, a name collision may
#       occur, in which case, an empty dictionary is returned.
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/04/16 0.0 rag New - based upon clusterInfo
#---------------------------------------------------------------------
def configInfoAsDict( Type, scope = None ) :
  'configInfoAsDict( Type, scope = None ) - Return a dictionary of the specified WebSphere types.'
  result = {};
  funName = callerName();
  #-------------------------------------------------------------------
  # Note: If an error/exception occurs, return an empty dictionary.
  #-------------------------------------------------------------------
  try :
    #-----------------------------------------------------------------
    # For each entry, determine its name (if it has one), and add the
    # information to the dictionary result.
    # Note: Passing a scope of None is just like not passing one.
    #-----------------------------------------------------------------
    for entry in AdminConfig.list( Type, scope ).splitlines() :
      #---------------------------------------------------------------
      # is the configID surrounded by quotes?  If so, remove them.
      #---------------------------------------------------------------
      if ( entry[ 0 ] == '"' ) and ( entry[ -1 ] == '"' ) :
        name = entry[ 1:-1 ];
      else :
        name = entry;
      #---------------------------------------------------------------
      # The item name, if it exists, preceeds the opening parenthesis.
      #---------------------------------------------------------------
      name = name.split( '(', 1 )[ 0 ];
      if name :
        if result.has_key( name ) :
          raise IndexError( name );
        result[ name ] = entry;
  except NameError, e :
    result = {};
    print '%s: Name not found: %s' % ( funName, e );
  except IndexError, e :
    result = {};
    print '%s: Name collision: %s' % ( funName, e );
  except :
    Type, value = sys.exc_info()[ :2 ];
    result = {};
    print '%s: Exception  type: %s' % ( funName, str( Type ) );
    print '%s: Exception value: %s' % ( funName, str( Value ) );
  return result;


#---------------------------------------------------------------------
# Name: clusterInfo()
# Role: Return a dictionary having the primray key being the unique
#       cluster names, and the values being the associated configID
#       for that cluster
# Example: clusters = clusterInfo()
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/04/16 0.2 rag Fix - Rewrite using configInfoAsDict()
# 09/11/14 0.1 rag Fix - Rewrite using ServerCluster
# 08/10/29 0.0 rag New - based upon need for createClusterMember.py
#---------------------------------------------------------------------
def clusterInfo( scope = None ) :
  'clusterInfo( scope = None ) - Return a dictionary of the cluster members, and their configuration IDs.'
  return configInfoAsDict( 'ServerCluster', scope );


#---------------------------------------------------------------------
# Name: configurable
# Role: Return true (1) if wsadmin AdminConfig object is available
#       (0) otherwise
# Note: This can only occur when wsadmin fails to connect to the
#       specified Application Server on the specified/implied port.
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/05/24 0.1 rag Add - New, based upon usefulness
#---------------------------------------------------------------------
def configurable() :
  'configurable() - Return true (1) if AdminConfig object is available, false (0) otherwise'
  try :
    host   = AdminConfig.list( 'Server' );
    result = 1;                        # True  = AdminConfig object is available
  except :
    result = 0;                        # False = AdminConfig object not available
  return result;


#---------------------------------------------------------------------
# Name: displayDict
# Role: To display the contents of a dictionary in a more readable format
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/05/28 0.5 rag fix - Need to check string len before accessing [ 0 ] ...
# 10/05/13 0.4 rag fix - Add code to handle double quoted "list" values
# 10/05/12 0.3 rag fix - Add try / except in case dict.keys() doesn't exist
#                  add - New code to display "list" values better
# 10/04/08 0.2 rag Fix - Handle "empty" dictionary
# 09/11/14 0.1 rag Fix - Add optional width parm for key values
# 09/04/07 0.0 rag New - Based upon work for the book
#---------------------------------------------------------------------
def displayDict( dict, width = None ) :
  'displayDict( dict, width = None ) - Display dictionary contents in key name order'
  try :
    names = dict.keys();
    names.sort();
    if dict :
      if not width :
        width = max( [ len( x ) for x in names ] );
      for name in names :
        value = dict[ name ];
        if len( value ) > 0 and value[ 0 ] == '[' and value[ -1 ] == ']' and value.count( ' ' ) > 0 :
          print '%*s : [' % ( width, name );
          #-----------------------------------------------------------
          # Special case: Check for double quoted items.
          # e.g., Config IDs containing embedded blanks.
          #-----------------------------------------------------------
          if value.find( '"' ) < 0 :
            for item in value[ 1:-1 ].split( ' ' ) :
              print '%*s    %s' % ( width, ' ', item );
          else :
            value = value[ 1:-1 ];     # Remove brackets '[' & ']'
            while value :              # As long as data remains...
              if value[ 0 ] == '"' :   # Is this item double quoted?
                item, value = value[ 1: ].split( '"', 1 );
                value = value.lstrip();# Discard any leading blanks
              else :                   # Leading item isn't quoted
                item, value = value.split( ' ', 1 );
              print '%*s    %s' % ( width, ' ', item );
          print '%*s   ]' % ( width, ' ' );
        else :
          print '%*s : %s' % ( width, name, value );
  except :
    Type, value = sys.exc_info()[ :2 ];
    print '%s() exception:\n  type: %s\n value: %s' % ( callerName(), str( Type ), str( value ) );


#---------------------------------------------------------------------
# Name: findNamedConfigType()
# Role: To return the first configId of the resource of the specified
#       Type having the specified name attribute.
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/04/22 0.0 rag New
#---------------------------------------------------------------------
def findNamedConfigType( name, Type, scope = None, attr = None ) :
  'findNamedConfigType( name, Type, scope = None, attr = None ) - Return the configId of the item having the given name and type.'
  try :
    #-----------------------------------------------------------------
    # Note: Passing a scope of None is just like not specifying one.
    #-----------------------------------------------------------------
    if not attr :
      attr = 'name';
    for element in AdminConfig.list( Type, scope ).splitlines() :
      if name == AdminConfig.showAttribute( element, attr ) :
        return element;
  except :
    pass;
  return None;


#---------------------------------------------------------------------
# Name: findTypes()
# Role: Returns the list of configuration types that containing the
#       specified text.
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/06/04 0.0 rag New - based upon usefulness
#---------------------------------------------------------------------
def findTypes( text ) :
  'findTypes( text ) - Returns the list of configuration types that containing the specified text.'
  result = [];
  for Type in AdminConfig.types().splitlines() :
    if Type.find( text ) > -1 :
      result.append( Type );
  return result;


#---------------------------------------------------------------------
# Name: fixFileName()
# Role: Unfortunately, an ugly "wart" exists when dealing with Windows
#       fileNames.  Specifically, some Windows fileNames, when passed
#       into a wsadmin script can inadvertently cause "correct"
#       filename characters to be misinterpreted as special Jython
#       "escape" characters.  This occurs when the filename, or
#       directory name character that occur immediately after a
#       directory delimiter (i.e., '\\') happen to be one of the
#       "special" Jython escape characters.  Instead of correctly
#       identifying the directory delimiter as '\\', and leaving the
#       subsequent character alone, the directory delimiter and the
#       character that follows are interpreted as one of these
#       "special" Jython escape character.  So, the purpose of this
#       routine is to correct that interpretation error.
# Note: This routine is equivalent to:
#       def fixFileName( fileName ) :
#         result = fileName.replace( '\a', r'\a' )
#         result = result.replace( '\b', r'\b' )
#         result = result.replace( '\f', r'\f' )
#         result = result.replace( '\n', r'\n' )
#         result = result.replace( '\r', r'\r' )
#         result = result.replace( '\t', r'\t' )
#         result = result.replace( '\v', r'\v' )
#         return result
#---------------------------------------------------------------------
def fixFileName( fileName ) :
  'fixFileName( filename ) - Return the specified string with selected escape characters unescaped.'
  return fileName.replace(
    '\a', r'\a' ).replace(
    '\b', r'\b' ).replace(
    '\f', r'\f' ).replace(
    '\n', r'\n' ).replace(
    '\r', r'\r' ).replace(
    '\t', r'\t' ).replace(
    '\v', r'\v' );


#---------------------------------------------------------------------
# Name: getEndPointName()
# Role: Return the name of the configured EndPoint for the given port
#       on the specified server (or '' if the port is not configured).
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/04/22 0.0 rag New
#---------------------------------------------------------------------
def getEndPointName( port, serverName, nodeName = None ) :
  'getEndPointName( port, serverName, nodeName = None ) - Return the name of the configured EndPoint for the given port on the specified server.'
  if type( port ) == type( 0 ) :
    port = `port`;                     # Ensure that the port number is a string
  return getPorts( serverName, nodeName ).get( port, '' );


#---------------------------------------------------------------------
# Name: getEndPoints()
# Role: Return a dictionary, indexed by endPoint names, of the ports
#       configured for the specified server.
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/04/22 0.0 rag New
#---------------------------------------------------------------------
def getEndPoints( serverName, nodeName = None ) :
  'getEndPoints( serverName, nodeName = None ) - Return a dictionary of the configured EndPoints for the specified server.'
  result = {};
  #-------------------------------------------------------------------
  # If a nodeName is specified, use it to limit the search scope.
  #-------------------------------------------------------------------
  if nodeName :
    scope = findNamedConfigType( nodeName, 'Node' );
  else :
    scope = None;
  #-------------------------------------------------------------------
  # Locate the named (and optionally scoped) 'ServerEntry'
  #-------------------------------------------------------------------
  serverEntry = findNamedConfigType( serverName, 'ServerEntry', scope, 'serverName' );
  if serverEntry :
    #-----------------------------------------------------------------
    # for each NamedEndPoint on this server...
    #-----------------------------------------------------------------
    for namedEndPoint in AdminConfig.list( 'NamedEndPoint', serverEntry ).splitlines() :
      Name = AdminConfig.showAttribute( namedEndPoint, 'endPointName' );
      epId = AdminConfig.showAttribute( namedEndPoint, 'endPoint' );
      result[ Name ] = AdminConfig.showAttribute( epId, 'port' );
  #-------------------------------------------------------------------
  # Return either an empty dictionary, or one indexed by EndPointNames,
  # containing the associated port numbers.
  #-------------------------------------------------------------------
  return result;


#---------------------------------------------------------------------
# Name: getPort()
# Role: Return the configured Port number for the specified (named)
#       EndPoint on the specified server.
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/04/22 0.0 rag New
#---------------------------------------------------------------------
def getPort( endPointName, serverName, nodeName = None ) :
  'getPort( endPointName, serverName, nodeName = None ) - Return the configured Port number for the specified (named) EndPoint on the the specified server.'
  return getEndPoints( serverName, nodeName ).get( endPointName, '' );


#---------------------------------------------------------------------
# Name: getPorts()
# Role: Return a dictionary, indexed by port number, of the named
#       EndPoints for the specified server.
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/04/22 0.0 rag New
#---------------------------------------------------------------------
def getPorts( serverName, nodeName = None ) :
  'getPorts( serverName, nodeName = None ) - Return a dictionary, indexed by port number, of the named EndPoints for the specified server.'
  result    = {};
  endPoints = getEndPoints( serverName, nodeName );
  for name, port in endPoints.items() :
    result[ port ] = name;
  return result;


#---------------------------------------------------------------------
# Name: localMode
# Role: Return true (1) if wsadmin is running in "local mode", false
#       (0) otherwise
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 09/11/15 0.1 rag Add - New, based upon usefulness
#---------------------------------------------------------------------
def localMode() :
  'localMode() - Return true (1) if executing in "local" mode, false (0) otherwise'
  try :
    host   = AdminControl.getHost();
    result = 0;                        # False = we are connected
  except :
    result = 1;  # True  = AdminControl service not available
  return result;


#---------------------------------------------------------------------
# Name: MBattrAsDict
# Role: Utility routine used to return a dictionary of attributes for
#       the specified mbean
# Note: Depends upon availability of WSAS Admin Objects via sys.modules
# History:
#   when  ver who what
# -------- --- --- ---------------------------------------------------
# 09/11/10 0.1 rag Add - Add 'Modifiable' value to result
# 09/04/08 0.0 rag New - insight obtained while writing the book
#---------------------------------------------------------------------
def MBattrAsDict( mbean ) :
  "MBattrAsDict( mbean ) - Given an MBean string, return a dictionary of it's attributes."
  funName = callerName();              # Name of this function
  result = {};                         # Result is a dictionary
  #-------------------------------------------------------------------
  # The first line of Help.attributes() result contains the "column
  # headings", not values, and is ignored by slicing using [ 1: ].
  # For each valid attribute, we use the name to get the value
  #-------------------------------------------------------------------
  try :                                # Be prepared for an error
    import Help, AdminControl;         # Get access to WSAS objects
    attr = Help.attributes( mbean ).splitlines()[ 1: ];
    for att in attr :
      name = att.split( ' ', 1 )[ 0 ]; # Everything ahead of 1st space
      #---------------------------------------------------------------
      # Unfortunately, for some attribute names, an attempt to
      # getAttribute() will cause an exception, these we ignore.
      #---------------------------------------------------------------
      try :
        result[ name ] = AdminControl.getAttribute( mbean, name );
      except :
        pass;
    #-----------------------------------------------------------------
    # After all available attributes have been retrieved, see if one
    # name "Modifiable" exists.  If it does, we have a problem, which
    # needs to be reported.
    # Otherwise, use list comprehension to locate those attributes
    # that are specified as "Read-Write".  Put all of these attribute
    # names into a list, and save it as result[ 'Modifiable' ].
    #-----------------------------------------------------------------
    # Note: Specifying x.split( ' ', 1 )[ 0 ] means that a maximum of
    #       1 split will occur (i.e., strings will be created), and
    #       only the first (i.e., the leading non-blank characters)
    #       will be returned.
    #-----------------------------------------------------------------
    if result.has_key( 'Modifiable' ) :
      print '%(funName)s: "Modifiable" attribute already exists, and not replace.' % locals();
    else :
      result[ 'Modifiable' ] = [ x.split( ' ', 1 )[ 0 ] for x in attr if x.endswith( 'RW' ) ];
  except :
    notavail = 'AdminControl service not available';
    #-----------------------------------------------------------------
    # One likely source of errors is that an invalid MBean was
    # provided, in which case an empty dictionary is returned.
    #-----------------------------------------------------------------
    ( kind, value ) = sys.exc_info()[ :2 ];
    ( kind, value ) = str( kind ), str( value );
    if value.endswith( notavail ) :
      if 'AdminTask' in sys.modules.keys() :
        print '%(funName)s "%(notavail)s": Was wsadmin started with "-conntype none"?' % locals();
      else :
        print '%(funName)s "%(notavail)s": wsadmin isn\'t connected to a server.' % locals();
    elif value.find( 'WASX7025E' ) > -1 :
      print '%(funName)s: Invalid mbean identifier: %(mbean)s' % locals();
    else :
      print 'Exception  type: ' + kind;
      print 'Exception value: ' + value;
  return result;


#---------------------------------------------------------------------
# Name: MBnameAsDict
# Role: Utility routine used to return a dictionary of name/value
#       details from an MBean name
# Note: Exception handler requires sys module
# History:
#   when  ver who what
# -------- --- --- ---------------------------------------------------
# 08/10/27 0.1 rag Minor code cleanup
# 08/09/17 0.0 rag New - insight obtained while writing the book
#---------------------------------------------------------------------
def MBnameAsDict( beanName ) :
  'MBnameAsDict( beanName ) - Given an MBean name, return a dictionary of its name/value components.'
  funName = callerName();              # Name of this function
  domain  = 'WebSphere:';              # MBean name prefix
  result  = {};                        # Result is a dictionary
  try :                                # Be prepared for an error
    #-----------------------------------------------------------------
    # Verify that we are working with a WebSphere MBean
    #-----------------------------------------------------------------
    if beanName.startswith( domain ) :
      #---------------------------------------------------------------
      # The rest of MBean name should be composed of comma separated
      # name=value pairs.
      #---------------------------------------------------------------
      for field in beanName[ len( domain ): ].split( ',' ) :
        ( name, value ) = field.split( '=', 1 );
        result[ name ] = value;
    else :
      print '''%(funName)s:
Warning: Specified MBean name doesn\'t start with "%(domain)s" and is ignored.
  MBean name: "%(beanName)s"''' % locals();
  except :
    ( kind, value ) = sys.exc_info()[ :2 ];
    print '''%(funName)s: Unexpected exception.\n
  Exception  type: %(kind)s
  Exception value: %(value)s''' % locals();
  return result;


#---------------------------------------------------------------------
# Name: memberInfo()
# Role: Return a dictionary having the primary key being the unique
#       cluster member name, and the value being the associated
#       configID for that member.
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/04/16 0.0 rag New - Write using configInfoAsDict()
#---------------------------------------------------------------------
def memberInfo( scope = None ) :
  'memberInfo( scope = None ) - Return a dictionary of the cluster member names, and their configuration IDs.'
  return configInfoAsDict( 'ClusterMember', scope );


#---------------------------------------------------------------------
# Name: nodeInfo()
# Role: Return a dictionary having the primary key being the unique
#       node names, and the values being the associated configID
#       for each node.
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/04/16 0.0 rag New - Write using configInfoAsDict()
#---------------------------------------------------------------------
def nodeInfo( scope = None ) :
  'nodeInfo( scope = None ) - Return a dictionary of the node names, and their configuration IDs.'
  return configInfoAsDict( 'Node', scope );


#---------------------------------------------------------------------
# Name: nvListAsDict()
# Role: To display the contents of a dictionary in a more readable format
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 09/11/15 0.1 rag Add - docstring
# 09/08/18 0.0 rag New - see stringAsNestedList()
#---------------------------------------------------------------------
def nvListAsDict( nvList ):
  'nvListAsDict( mvList ) - Convert a list containing name/value pairs into a dictionary'
  result = {};
  for name, value in nvList :
    result[ name ] = value;
  return result;


#---------------------------------------------------------------------
# Name: nvTextListAsDict
# Role: Convert a list of name/value pairs found in the specified text
#       string into a dicationary.
# Note: Depends upon availability of WSAS Admin Objects via sys.modules
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/01/27 0.5 rag Fix - Change "cmdName" to "funName"
# 09/11/15 0.4 rag Add - docstring
# 09/04/07 0.3 rag Add - Added displayDict() call to example
# 09/03/21 0.2 rag Add - Add "role" description & corrected example
# 08/12/18 0.1 rag Fix - Handle "no value" pair (e.g., "[nodeShortName ]")
# 08/12/17 0.0 rag New - Based upon work for book
#---------------------------------------------------------------------
# Example use:
# > from WAuJ_utilities import nvTextListAsDict, displayDict
# > sDict = nvTextListAsDict( AdminTask.showServerTypeInfo( 'APPLICATION_SERVER' ) )
# > displayDict( sDict )
#---------------------------------------------------------------------
def nvTextListAsDict( text ) :
  'nvTextListAsDict( text ) - Convert a list of name/value pairs into a dictionary.'
  funName = callerName();
  #-------------------------------------------------------------------
  # Initialize the dictionary to be returned
  #-------------------------------------------------------------------
  result = {};
  #-------------------------------------------------------------------
  # Verify that the specified string "looks" right...
  #-------------------------------------------------------------------
  if ( text.count( '[' ) == text.count( ']' ) ) and ( text[ 0 ] == '[' ) and ( text[ -1 ] == ']' ) :
    #-----------------------------------------------------------------
    # Remove outer brackets (i.e., '[]') and then leading/trailing blanks
    #-----------------------------------------------------------------
    innerText = text[ 1:-1 ].strip();
    #-----------------------------------------------------------------
    # Locate a possible unused character so the list of values can
    # easily be split into name value pairs
    #-----------------------------------------------------------------
    delimiters = ',.|!@#';             # Possible delimiter values
    for delim in delimiters :
      #---------------------------------------------------------------
      # If this char (delim) doesn't exist in the string, put it in,
      # between the close and open brackets so that it can be used to
      # split the line into a list of strings like '[name value]'.
      #---------------------------------------------------------------
      if innerText.count( delim ) == 0 :
        for pair in innerText.replace( '] [', ']%s[' % delim ).split( delim ) :
          #-----------------------------------------------------------
          # verify that the string starts and ends with brackets...
          # Note: a == b == c is only true if both a == b and b == c
          #-----------------------------------------------------------
          if ( pair.count( '[' ) == pair.count( ']' ) == 1 ) and ( pair[ 0 ] == '[' ) and ( pair[ -1 ] == ']' ) :
            #---------------------------------------------------------
            # Occasionally, we have a situation where pair contains
            # only a name, and not a name/value pair.
            # So, this code was added to handle that rare situation.
            #---------------------------------------------------------
            contents = pair[ 1:-1 ].strip();
            try :
              ( name, value ) = contents.split( ' ', 1 );
            except :
              ( name, value ) = ( contents, '' );
            result[ name ] = value;
          else :
            print '%s error - Unexpected text: "%s" (ignored).' % ( funName, pair );
        #-------------------------------------------------------------
        # All name/pair sub-strings have been processed, we're done
        #-------------------------------------------------------------
        break;
    else :
      print '%s error - Unable to split data, empty dictionary returned.' % funName;
      return {}
  else :
    print '%s error - Unexpected data format: "%s", empty dictionary returned.' % ( funName, text );
  return result;


#---------------------------------------------------------------------
# Name: scopedWSASvariables()
# Role: Return a dictionary of the specific WebSphere Application
#       Server (WSAS) variables scoped by the specified configId.
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/05/19 0.2 rag Fix handle KeyError for VMdict[ 'entries' ]
#                  Fix handle empty VMid
# 10/04/22 0.1 rag Add docstring
# 10/04/18 0.0 rag New
#---------------------------------------------------------------------
def scopedWSASvariables( configId ) :
  'scopedWSASvariables( configId ) - Return a dictionary of the WSAS variables scoped by the specified configId.'
  funName = callerName();
  start = configId.find( '(' );
  if start < 0 :
    print '%s() error - no \'(\' found in configId: "%s"' % ( funName, configId );
    return
  fini = configId.find( '|' );
  if fini < 0 :
    print '%s*( error - no \'|\' found in configId: "%s"' % ( funName, configId );
    return
  #-------------------------------------------------------------------
  # Quick and easy extraction of the part of the configId we need to
  # filter the VariableMap configuration items.
  #-------------------------------------------------------------------
  prefix = configId[ start : fini + 1 ]
  VMid = configIdFilter( 'VariableMap', prefix );
  #-------------------------------------------------------------------
  # Use this VariableMap configId to determine which entries exist.
  #-------------------------------------------------------------------
  result = {};
  if VMid :
    VMdict = showAsDict( VMid );
    entries = VMdict.get( 'entries', '[]' )[ 1:-1 ];
    #-----------------------------------------------------------------
    # If the list of entry configIds is not empty, extrct the details.
    #-----------------------------------------------------------------
    if entries :
      for entry in entries.split( ' ' ) :
#       print 'entry:', entry
        entryDict = showAsDict( entry );
        result[ entryDict[ 'symbolicName' ] ] = entryDict[ 'value' ]
  return result;


#---------------------------------------------------------------------
# Name: serverInfo()
# Role: Return a dictionary having the primary key being the unique
#       server name, and the value being the associated configID for
#       that server.
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/04/16 0.0 rag New - Write using configInfoAsDict()
#---------------------------------------------------------------------
def serverInfo( scope = None ) :
  'serverInfo( scope = None ) - Return a dictionary of the server names, and their configuration IDs.'
  return configInfoAsDict( 'Server', scope );


#---------------------------------------------------------------------
# Name: showAsDict
# Role: Convert result of AdminConfig.show( configID ) to a dictionary
# Note: Depends upon availability of WSAS Admin Objects via sys.modules
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 09/08/08 0.1 rag Fix - remove quotes of value
# 08/09/06 0.0 rag New - Based upon work down for IMPACT 2008
#---------------------------------------------------------------------
# Example use:
# > from WAuJ_utilities import showAsDict
# > servers = AdminConfig.list( 'Server' ).splitlines()
# > svrDict = showAsDict( servers[ 0 ] )
#---------------------------------------------------------------------
def showAsDict( configId ) :
  'showAsDict( configId ) - Return a dictionary of the AdminConfig.show( configID ) result.'
  result = {};
  try :
    import AdminConfig;                # Get access to WSAS objects
    #-----------------------------------------------------------------
    # The result of the AdminConfig.show() should be a string
    # containing many lines.  Each line of which starts and ends
    # with brackets.  The "name" portion should be separated from the
    # associated value by a space.
    #-----------------------------------------------------------------
    for item in AdminConfig.show( configId ).splitlines() :
      if ( item[ 0 ] == '[' ) and ( item[ -1 ] == ']' ) :
        ( key, value ) = item[ 1:-1 ].split( ' ', 1 );
        if ( value[ 0 ] == '"' ) and ( value[ -1 ] == '"' ) :
          value = value[ 1:-1 ];
        result[ key ] = value;
  except NameError, e :
    print 'Name not found: ' + str( e );
  except :
    ( kind, value ) = sys.exc_info()[ :2 ];
    print 'Exception  type: ' + str( kind );
    print 'Exception value: ' + str( value );
  return result;


#---------------------------------------------------------------------
# Name: stringAsNestedList()
# Role: Parse / convert a "well formed" input string into a nested
#       list using a very simple Finite State Machine (FSM) and stack
#       so recursive descent isn't needed.
#
# States
#   -1 : Finished
#    0 : Looking for brackets
#    1 : collecting characters
#
# Finite State machine (FSM)
#
#        +-----+-----+-----+
# States | -1  |  0  |  1  |
#        +=====+=====+=====+
#   '['  |     |  A  |     |
#        +-----+-----+-----+
#   ']'  |     |  B  |  E  |
#        +-----+-----+-----+
#   ' '  |     |  -  |  D  |
#        +-----+-----+-----+
#  other |     |  C  |     |
#        +-----+-----+-----+
#
# Actions:
#    A | Current_List = [];     Push( Current_List ) onto our stack
#    B | Complete Current_List; Pop TOS; Append Current_List to TOS
#    C | Start saving characters
#    D | Previous "word" complete.  Save it.
#    E | Handle closing bracket
#    F | Save current character
#    - | Ignore
#
# Note: TOS == Top of Stack
#
# Example:
#   > import WAuJ_utilities as WAuJ
#   > ssText = AdminTask.getActiveSecuritySettings();  # New in 7.0
#   > ssNL   = WAuJ.stringAsNestedList( ssText );
#   > ssDict = WAuJ.nvListAsDict( ssNL );
#
# History:
#   when  ver who what
# -------- --- --- ---------------------------------------------------
# 09/11/15 0.1 rag Add - docstring
# 09/08/18 0.0 rag New - based upon need
#---------------------------------------------------------------------
def stringAsNestedList( str ) :
  'stringAsNestedList( str ) - Convert a well formed nested string list into a nested list of strings'
  str    = str.replace( '\r', '' );    # Remove all Carriage Return
  str    = str.replace( '\n', '' );    #    ... and Line Feed chars
  result = [];                         # initialize as an empty list
  state  = 0;                          # Looking for brackets
  lst    = None;                       # Current list
  lstStr = None;                       # Collecting string
  #-------------------------------------------------------------------
  # Loop through all the characters in the input string
  #-------------------------------------------------------------------
  for c in str :                       #
    if state == 0 :                    # State <- Looking for bracket
      if c == '[' :                    # Start a new list
        lst = [];                      # Initialize "current" list
        result.append( lst );          # Push onto the stack
      elif c == ' ' :                  #
        pass;                          # Ignore blanks between brackets
      elif c == ']' :                  #
        if len( lst ) == 1 :           # Does list contain only 1 element?
          lst.append( '' );            #   Append implied empty value.
        #-------------------------------------------------------------
        # Get the just-built list of the level (lst) and append it 
        # to the parent list.
        #-------------------------------------------------------------
        result.pop();                  # Remove current lst from TOS
        if len( result ) > 0 :         #
          result[ -1 ].append( lst );  # Append to the TOS, which
          lst = result[ -1 ];          # becomes the current list
        else :                         #
          result.append( lst );        # We should be done now
          state = -1;                  # State <- Finished
      else :                           #
        lstStr = [ c ];                # First character to be collected
        state = 1;                     # State <- collecting characters
    elif state == 1 :                  # Collecting characters
      if c == ' ' :                    # Delimiter?
        lst.append( ''.join( lstStr ) ); # Collected characters => string
        state = 0;                     # State <- "Looking for bracket"
      elif c == ']' :                  #
        lst.append( ''.join( lstStr ) ); # Collected string
        #-------------------------------------------------------------
        # Get the just-built list of the level (lst) and append it 
        # to the parent list.
        #-------------------------------------------------------------
        result.pop();                  # remove lst from TOS
        if len( result ) > 0 :         #
          result[ -1 ].append( lst );  # Append to the upper level, which
          lst = result[ -1 ];          # becomes the current list from
          state = 0;                   # State <- "Looking for bracket"
        else :                         #
          result.append( lst );        # We should be done now
          state = -1;                  # State <- Finished
      else :                           #
        lstStr.append( c );            # Save the current character
    elif state == -1 :                 # Finished?
      return result[ 0 ];              #
  if state == -1 :                     #
    assert len( result ) == 1;         #
    return result[ 0 ];                #
  else :                               #
    print 'stringAsNestedList() Unexpected Error.'
    print '  state:', state;           #
    print ' result:', repr( result );  #
    print '    lst:', repr( lst );     #
    print ' lstStr:', repr( lstStr );  #
    return None;                       #


#---------------------------------------------------------------------
# Name: stringListAsList
# Role: Convert a string list into a list of strings.
# Note: Convenient for converting a list of configuaration IDs (any of
#       which may be surrounded by quotes).
# Note: Any surrounding quotes are removed from the list entries
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 09/11/15 0.1 rag Fix - Last entry doesn't have to have quotes
#                  Add - docstring
# 09/11/14 0.0 rag New - Based upon word done with cluster members
#---------------------------------------------------------------------
# Example use:
# > import WAuJ_utilities as WAuJ
# > clusters = WAuJ.clusterInfo();
# > for cluster in clusters.keys() :
# >   clustDict = WAuJ.showAsDict( clusters[ cluster ] );
# >   print cluster
# >   for member in WAuJ.stringListAsList( clustDict[ 'members' ] ) :
# >     print '  %s : %s' % ( member.split( '(', 1 )[ 0 ], member ) 
#---------------------------------------------------------------------
def stringListAsList( str ) :
  'stringListAsList( str ) - Convert an unnested string list into a list of strings'
  result = [];
  funName = callerName();
  if str and str[ 0 ] == '[' and str[ -1 ] == ']' :
    str = str[ 1:-1 ] + ' ';      # Guarantee trailing space
    try :
      #---------------------------------------------------------------
      # While string contains data
      #---------------------------------------------------------------
      while str :
        #---------------------------------------------------------------
        # Does string start with a double quote?
        #---------------------------------------------------------------
        if str[ 0 ] == '"' :
          ( val, str ) = str[ 1: ].split( '"', 1 );
          result.append( val );
        #---------------------------------------------------------------
        # Does string start with a space?
        #---------------------------------------------------------------
        elif str[ 0 ] == ' ' :
          str = str[ 1: ];
        #---------------------------------------------------------------
        # Next delimiter is a space (if one exists).
        #---------------------------------------------------------------
        else :
          ( val, str ) = str.split( ' ', 1 );
          result.append( val );
    except NameError, e :
      print '%s: Name not found: %s' % ( funName, str( e ) );
    except :
      ( kind, value ) = sys.exc_info()[ :2 ];
      print '''%(funName)s: Unexpected error:
  Exception  type: %(kind)s
  Exception value: %(value)s''' % locals();      
  else :
    print '%s: Unexpected data format.  Missing []' % funName;
  return result;


#---------------------------------------------------------------------
# Name: unravel()
# Role: Use the specified resource configId (of a Server, Node, Cell,
#       ServerCluster, or ClusterMember), to resolve the value of the
#       specified WSAS variable.
# Note: To resolve, or completely "unravel" a string containing WSAS
#       variable references, we need to first obtain a dictionary of
#       the variables that exist for this context (e.g., for a specific
#       AppServer).
# e.g.: wsadmin>import WAuJ_utilities as WAuJ;
#       wsadmin>server   = AdminConfig.list( 'Server' ).splitlines()[ -1 ];
#       wsadmin>ts       = AdminConfig.list( 'TraceService', server );
#       wsadmin>tsDict   = WAuJ.showAsDict( ts );
#       wsadmin>tl       = tsDict[ 'traceLog' ];
#       wsadmin>tlDict   = WAuJ.showAsDict( tl );
#       wsadmin>tracelog = tlDict[ 'fileName' ]; #    ${SERVER_LOG_ROOT}/trace.log
#       wsadmin>print WAuJ.unravel( tracelog, server );
#       C:\IBM\WebSphere\AppServer70\profiles\AppSrv01/logs/server1/trace.log
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/04/19 0.1 rag Fix - Check for (and handle) '[]' (empty WSAS variable values)
# 10/04/18 0.0 rag New
#---------------------------------------------------------------------
def unravel( value, configId ) :
  'unravel( value, configId ) - Complete variable substitution of specified value, using specified scoping configId.'
  funName = callerName();              # Name of current routine
  variables = WSASvariables( configId );
  var = re.compile( '\${(\w+)}' );     # Find a valid variable 
  while value.find( '${' ) > -1 :      # Does it look like one exists?
    mo = var.search( value );          # Match Object (mo)
    if mo :                            # One exists
      name = mo.group( 1 );            # Whole reference e.g., "${NAME}"
      if not variables.has_key( name ) :
        print '%s() error - Missing variable: "%s"' % ( funName, name );
        break;                         # We're done
      val   = variables[ name ];
      if val == '[]' :                 # Check for an "empty string"
        val = '';                      #
      value = re.sub( var, val, value );
    else :
      print '%s() error - No substitution found.' % funName;
  return value;


#---------------------------------------------------------------------
# Name: Usage()
# Role: Display information about how the library module should be used.
#---------------------------------------------------------------------
def Usage( cmd = 'WAuJ_utilities' ) :
  'Usage( cmd ) - Display the usage information for the module.'
  #-------------------------------------------------------------------
  # To be able to access to the module docstring (i.e., __doc__), we
  # have to:
  #-------------------------------------------------------------------
  # 1. Define a global variable, and bind the value of __doc__ to it
  #    (see below)
  # 2. Copy the contents of the global variable to a local variable
  #    This lets us use locals() to access the value.
  #-------------------------------------------------------------------
  info = docstring;

  print '''     File: %(cmd)s.py
%(info)s
 Examples:
   import %(cmd)s as WAuJ\n
   ...
   if WAuJ.localMode() :
     print "Connection required."''' % locals();


#---------------------------------------------------------------------
# Name: WSASvariables()
# Role: Return a dictionary of the specific WebSphere Application
#       Server (WSAS) variables for the specified resource (i.e.,
#       Server, Node, ServerCluster, ClusterMember, or Cell).
# History:
#   when  ver who what
# -------- --- --- ------------------------------------------
# 10/05/19 0.2 rag Fix Use AdminConfig.getObjectType()
# 10/04/22 0.1 rag Add docstring
# 10/04/18 0.0 rag New
#---------------------------------------------------------------------
def WSASvariables( configId ) :
  'WSASvariables( configId ) - Return a dictionary of the WSAS variables.'
  result = {};
  mo = re.compile( '\.xml#(\w+)_\d+\)$' ).search( configId ) ;
  if mo :
    cfgDict  = configIdAsDict( configId );
    itemDict = showAsDict( configId );

    #-----------------------------------------------------------------
    # Extract the configuration type from the configId
    #-----------------------------------------------------------------
    Type = AdminConfig.getObjectType( configId );
    if Type == 'Server' :
      #---------------------------------------------------------------
      # We were provided with the server configId
      #---------------------------------------------------------------
      serverVM   = scopedWSASvariables( configId );

      #---------------------------------------------------------------
      # Build the configId of the containing Node
      #---------------------------------------------------------------
      nodePrefix = '(cells/%(cells)s/nodes/%(nodes)s|' % cfgDict;
      nodeId     = configIdFilter( 'Node', nodePrefix );
      nodeVM     = scopedWSASvariables( nodeId );

      #---------------------------------------------------------------
      # Build the configId of the containing Cell
      #---------------------------------------------------------------
      cellPrefix = '(cells/%(cells)s|' % cfgDict;
      cellId     = configIdFilter( 'Cell', cellPrefix );

      #---------------------------------------------------------------
      # Start with the cell level variables.
      #---------------------------------------------------------------
      result     = scopedWSASvariables( cellId );

      #---------------------------------------------------------------
      # If the server is a member of a cluster, get that configId too.
      # And add any of these to the result.
      #---------------------------------------------------------------
      if itemDict.has_key( 'clusterName' ) :
        clusterPrefix = '(cells/%s/clusters/%s|' % ( itemDict[ 'cells' ], itemDict[ 'clusterName' ] );
        clusterId     = configIdFilter( 'Node', clusterPrefix );
        result.update( scopedWSASvariables( clusterId ) );
     
      #---------------------------------------------------------------
      # Finally, add the Node and server variables to the dictionary.
      #---------------------------------------------------------------
      result.update( nodeVM );
      result.update( serverVM );
      return result;

    #-----------------------------------------------------------------
    # For a ClusterMember, the result = Cell level variable + any
    # cluster level variables + any that the cluster member may have.
    #-----------------------------------------------------------------
    if Type == 'ClusterMember' :
      cellPrefix = '(cells/%(cells)s|' % cfgDict;
      cellId     = configIdFilter( 'Cell', cellPrefix );
      result     = scopedWSASvariables( cellId );
      result.update( scopedWSASvariables( itemDict[ 'cluster' ] ) );
      result.update( scopedWSASvariables( configId ) );
      return result;

    #-----------------------------------------------------------------
    # For a Nodes & Clusters, the result = Cell level variable + any
    # variables for the specified resource.
    #-----------------------------------------------------------------
    if ( Type == 'Node' ) or ( Type == 'ServerCluster' ) :
      cellPrefix = '(cells/%(cells)s|' % cfgDict;
      cellId     = configIdFilter( 'Cell', cellPrefix );
      result     = scopedWSASvariables( cellId );
      result.update( scopedWSASvariables( configId ) );
      return result;

    #-----------------------------------------------------------------
    # The Cell is easy... just the cell level variables.
    #-----------------------------------------------------------------
    if Type == 'Cell' :
      result     = scopedWSASvariables( configId );
      return result;
      
    else :
      print '%s(): error - unrecognized configId type: "%s"' % ( callerName(), Type );
  else :
    print '%s(): error - unrecognized configId string: %s' % ( callerName(), configId );

  return;


#---------------------------------------------------------------------
# main: Verify that this file was imported, and not executed.
#---------------------------------------------------------------------
docstring = __doc__
if ( __name__ == 'main' ) or ( __name__ == '__main__' ) :
  Usage( __name__ );

