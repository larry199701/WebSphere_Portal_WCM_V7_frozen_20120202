#-------------------------------------------------------------------------------
#   Name: imt-post.py
#   Role: ISA Multi-Trace script - Used after recreate attempt
# Author: Robert A. (Bob) Gibson [rag] - bgibson@us.ibm.com
#   Book: WebSphere Application Server Administration Using Jython (WAuJ)
#   ISBN: 0-13-700952-6
#    See: http://www.ibmpressbooks.com/bookstore/product.asp?isbn=9780137009527
#
# Contents:
#   imt()            - Use property files to set AppServer log/trace settings
#   log()            - Write specified message if global Debug variable true
#   readAndProcess() - Read specified properties file and call processServer()
#   processServer()  - Perform the necessary configuration and active process changes
#   propfileAsDict() - Read specified properties file & return as a dictionary
#   Usage()          - Display script usage information & exit
#   updatePropfile() - Update the (same) properties file that was previously read
#
# History
#   date    ver  who  what
# --------  ---  ---  -----------------------------------------------------
# 10/06/28  0.6  rag  Fix Correction - typographical error.  There were multiple
#                         instances of statements like this:
#                           properties[ 'enable', 'true' ];
#                         instead of this:
#                           properties[ 'enable' ] = 'true';
# 10/06/26  0.5  rag  Fix remove call to env_dump() and print message, instead
# 10/06/18  0.4  rag  Add code to display version information
# 10/06/17  0.3  rag  Fix - paranoia check - call WAuJ.configurable()
#                     Add - env_dump()
# 10/06/16  0.2  rag  Fix - Add try/except around AdminControl
# 10/05/19  0.1  rag  Fix - Minor typographical error in attribute names
#                         - Don't change fileName
# 10/04/30  0.0  rag  New - based upon requirements defined by Dipak Shah
#-------------------------------------------------------------------------------

import java, os, os.path, re, sys;
import WAuJ_utilities as WAuJ;

#-------------------------------------------------------------------------------
# Global literals (e.g., mapped messages)
#-------------------------------------------------------------------------------
# Note: These are not variables, their values are not dynamically modified.
#-------------------------------------------------------------------------------
Debug   = 1;                 # True == 1, False == 0 : see log()
Delim   = '-' * 50;          # separator line (horizontal rule) of dashes
Version = '0.5';             #
Updated = '10/06/26';        #
MSG999  = 'Version: %(Version)s  Last Updated: %(Updated)s';

#-------------------------------------------------------------------------------
# Message(s) used by Usage()
#-------------------------------------------------------------------------------
MSG000 =  '''Command: %(cmdName)s\n
Purpose: wsadmin script used to assist with restoring the WebSphere AppServer
         Environment after problem recreate.   See imt-pre.py.\n
  Usage: -f %(cmdName)s.py <directory>\n
  Where: directory = The directory containing *.txt files to be processed.\n
Examples:
  wsadmin -lang jython -f %(cmdName)s.py C:\\Temp\n
  wsadmin -lang jython -profileName AppSrv01 -f %(cmdName)s.py ..\\temp\n''';

#-------------------------------------------------------------------------------
# Message(s) used by imt()
#-------------------------------------------------------------------------------
MSG001 = 'Invalid script invocation.';
MSG002 = 'Invalid directory specified: %s';

#-------------------------------------------------------------------------------
# Message(s) used by readAndProcess()
#-------------------------------------------------------------------------------
MSG011 = 'Processing: %(filename)s';
MSG012 = '  Ignoring: %(filename)s, which doesn\'t appear to be a "normal" text file.\n';
MSG013 = '  Ignoring: Node: %(node)s  Server: %(server)s - Unknown server.\n';
MSG014 = '  Ignoring: Server: %(server)s - Unknown server.\n';
MSG015 = '  Ignoring: %(server)s - ambiguous server - nodeName not specified\n';
MSG016 = '  Ignoring: serverName not specified.\n';

#-------------------------------------------------------------------------------
# Message(s) used by processServer()
#-------------------------------------------------------------------------------
MSG020 = '%(funName)s() error - unexpected # of "processDefinition" entries (%(numPD)d) for server: %(serverId)s';
MSG021 = '%(funName)s() error - missing/invalid "processDefinition" entry for server: %(serverId)s';
MSG022 = '%(funName)s() error - unexpected # of "jvmEntries" entries (%(numJVM)d) for processDefinition: %(serverId)s';
MSG023 = '%(funName)s() error - missing/invalid "jvmEntries" entry for processDefinition: %(pd)s';
MSG024 = '%(funName)s() error - missing "genericJvmArguments" attribute on jvmEntry: %(jvm)s';
MSG025 = '%(funName)s() - Restoring "genericJvmArguments" to "%(args)s"';
MSG026 = '%(funName)s() error - missing "verboseModeClass" attribute on jvmEntry: %(jvm)s';
MSG027 = '%(funName)s() error - invalid "verboseModeClass" value: %(vmc)s';
MSG028 = '%(funName)s() - Restoring "verboseModeClass" to "%(vmc)s"';
MSG029 = '\n%s(): Original settings being saved:\n%s%s';

MSG030 = '%(funName)s() - Configuration changes made, and being saved.';
MSG031 = '\n%(funName)s() - Error(s) encountered no changes made.';
MSG032 = '%(funName)s() - Restarting server: %(serverName)s\n';
MSG033 = '%(funName)s() - Server (%(serverName)s) unavailable for restart.';

MSG035 = '%(funName)s() error - properties file contains no "Old" entries.';

#-------------------------------------------------------------------------------
# Message(s) used by updatePropfile()
#-------------------------------------------------------------------------------
MSG040 = '%s() error : Can\'t update properties file ("%s") - is it Read/Only?';
MSG041 = '%s() exception : Required key ("%s") missing from properties dictionary.';
MSG042 = '%(funName)s() exception  type: %(kind)s\n%(funName)s() exception value: %(val)s';


#-------------------------------------------------------------------------------
# Name: env_dump()
# Role: Print diagnostic information about the current environment to assist
#       with problem determination.
#-------------------------------------------------------------------------------
def env_dump() :
  env = java.lang.System.getenv().toString();
  hr  = '-' * 70;

  print 'Environment:\n' + hr + '\n' + env;

  print hr + '\n\nEnvironment (by line):\n' + hr;
  print '\n'.join( env[ 1:-1 ].split( ', ' ) );

  print hr + '\n\ndir():\n' + hr;
  print dir();
  print hr;


#-------------------------------------------------------------------------------
# Name: imt()                          [ISA Multi-Tracing Task]
# Role: Verify user request, process properties file, and act accordingly
#-------------------------------------------------------------------------------
def imt() :
  #-----------------------------------------------------------------------------
  # Get the directory location from the command line
  #-----------------------------------------------------------------------------
  if len( sys.argv ) != 1 :
    print MSG001;
    Usage();
  directory = WAuJ.fixFileName( sys.argv[ 0 ] );

  #-----------------------------------------------------------------------------
  # Does the value really specify a directory?
  #-----------------------------------------------------------------------------
  if not os.path.isdir( directory ) :
    print MSG002 % directory;
    Usage();

  #-----------------------------------------------------------------------------
  # What "*.txt" files exist in it?
  #-----------------------------------------------------------------------------
  txtfiles = [ x for x in os.listdir( directory ) if x.endswith( '.txt' ) ]

  #-----------------------------------------------------------------------------
  # Process each .txt file
  #-----------------------------------------------------------------------------
  for filename in txtfiles :
    fqname = os.path.join( directory, filename );
    readAndProcess( fqname );


#-------------------------------------------------------------------------------
# Name: log()
# Role: Write the specified message, but only if global Debug variable is true.
#-------------------------------------------------------------------------------
def log( msg ) :
  if Debug :
    print msg;


#-------------------------------------------------------------------------------
# Name: readAndProcess()
# Role: Given a fully qualified filename, try to read it as a properties file,
#       and process the specified Application Server
# Note: This routine expects to be able to open, read & update the specified file.
#-------------------------------------------------------------------------------
def readAndProcess( fqname ) :
  funName = WAuJ.callerName();         # Where are we?
  log( 'Enter: %s()' % funName );
  #-----------------------------------------------------------------------------
  # Read the properties file, and load its name/value pairs into a dictionary
  #-----------------------------------------------------------------------------
  properties = propfileAsDict( fqname );

  #-----------------------------------------------------------------------------
  # If an empty dictionary is returned, there is no need to continue ...
  #-----------------------------------------------------------------------------
  if properties :
    #---------------------------------------------------------------------------
    # Does the specified node/server "currently" exist in the configuration?
    #---------------------------------------------------------------------------
    node   = properties.get( 'NodeName', '' );
    server = properties.get( 'ServerName', '' );

    #---------------------------------------------------------------------------
    # Are both the node and server names are specified?
    #---------------------------------------------------------------------------
    if node and server :
      configId = AdminConfig.getid( '/Node:%s/Server:%s/' % ( node, server ) );
      if not configId :
        print MSG013 % locals();
        log( ' Exit: %s() - unknown node/server.' % funName );
        return;
      #-------------------------------------------------------------------------
      # Is only the server name specified?
      #-------------------------------------------------------------------------
    elif server and not node :
      cfgIDs = AdminConfig.getid( '/Server:%s/' % server ).splitlines();
      if len( cfgIDs ) == 1 :
        configId = cfgIDs[ 0 ];
      elif len( cfgIDs ) > 1 :
        print MSG015 % locals();
        log( ' Exit: %s() - ambiguous server.' % funName );
        return;
      else :
        print MSG014 % locals();
        log( ' Exit: %s() - unknown server(s).' % funName );
        return;
    else :
      print MSG016 % locals();
      log( ' Exit: %s() - serverName not specified.' % funName );
      return;
  else :
    #-------------------------------------------------------------------------
    # Empty dictionary returned ... nothing to do
    #-------------------------------------------------------------------------
    log( ' Exit: %s() - empty dictionary returned.' % funName );
    return;

  #-----------------------------------------------------------------------------
  # Now we can process the server, since we have verified its uniqueness.
  #-----------------------------------------------------------------------------
  processServer( properties, configId );

  log( ' Exit: %s()' % funName );


#-------------------------------------------------------------------------------
# Name: processServer()
# Role: Perform the necessary configuration and active process changes
# Parm: properties = Dictionary of values from properties file
#       configId   = identifies a unique Application Server to be processed
# Note: The original file contents and filename should be values within the
#       properties dictionary.  The original settings will be in entries having
#       an index prefix of "Old."
# i.e.: properties[ 'Old.contents' ] == Original file contents
#       properties[ 'Old.filename' ] == Original (fully qualified) filename
#-------------------------------------------------------------------------------
def processServer( properties, serverId ) :
  funName = WAuJ.callerName();         # Where are we?
  log( 'Enter: %s()' % funName );
  log( 'Server: %s' % serverId );      # What server do we process?

  #-----------------------------------------------------------------------------
  # Does this configuration ID have an active/reachable MBean?
  #-----------------------------------------------------------------------------
  try :
    MBean = AdminConfig.getObjectName( serverId );
  except :
    MBean = '';
  log( ' MBean: %s' % MBean );

  #-----------------------------------------------------------------------------
  # Extract the "Old" properties, removing the "Old." prefix from the index
  #-----------------------------------------------------------------------------
  Old = {};
  for prop in properties.keys() :
    if prop.startswith( 'Old.' ) :
      Old[ prop[ 4: ] ] = properties[ prop ];
      if prop != 'Old.filename' :      # Needed by updatePropFile()
        del( properties[ prop ] );

  #-----------------------------------------------------------------------------
  # If no "Old" properties exist, we're done.
  #-----------------------------------------------------------------------------
  if not Old :
    print MSG035 % locals();
    log( ' Exit: %s()' % funName );
    return;

  #-----------------------------------------------------------------------------
  # Get access to the JVM arguements, in case changes are required
  #-----------------------------------------------------------------------------
  sad = WAuJ.showAsDict( serverId );   # Server Attribute Dictionary
  pd  = sad.get( 'processDefinitions', '[]' )[ 1:-1 ].split( ' ' );
  numPD = len( pd );                   # Used by MSG020
  if numPD != 1 :                      # If zero, or multiple exist...
    print MSG020 % locals();           #   we have a problem.
    print Delim;                       #   display them, just in case
    for p in pd :                      #
      print '>> "%s"' % p;             #
    print Delim;                       #
    log( ' Exit: %s()' % funName );    #
    return;                            #

  #-----------------------------------------------------------------------------
  # The processDefinition should have exactly 1 JVM Entry.
  #-----------------------------------------------------------------------------
  if pd[ 0 ] :                         # false if pd == [ '' ]
    pdDict = WAuJ.showAsDict( pd[ 0 ] );
    jvm = pdDict.get( 'jvmEntries', '[]' )[ 1:-1 ].split( ' ' );
    numJVM = len( jvm );               # Used by MSG022
    if numJVM != 1 :                   #
      print MSG022 % locals();         #
      print Delim;                     #
      for j in jvm :                   #
        print '>> "%s"' % j;           #
      print Delim;                     #
      log( ' Exit: %s()' % funName );  #
      return;                          #
  else :                               #
    print MSG021 % locals();           #
    log( ' Exit: %s()' % funName );    #
    return;                            #

  #-----------------------------------------------------------------------------
  # Do generic JVM arguments need to be restored?
  #-----------------------------------------------------------------------------
  args = Old.get( 'JVMargs', '' ).strip();

  #-----------------------------------------------------------------------------
  # The jvmEntry should have exactly 1 genericJvmArguments Entry.
  #-----------------------------------------------------------------------------
  jvm = jvm[ 0 ];                      #
  if jvm :                             # false if jvm == ''
    jvmDict = WAuJ.showAsDict( jvm );  #
    if jvmDict.has_key( 'genericJvmArguments' ) :
      oldArgs = jvmDict[ 'genericJvmArguments' ];
      if args and args != oldArgs :    #
        if args == '[]' :              # Special case...
          args = '';                   #
        print MSG025 % locals();       #
        AdminConfig.modify( jvm, [ [ 'genericJvmArguments', args ] ] );
        log( 'change( [ [ "genericJvmArguments", "%s" ] ] )' % args );
    else :                             #
      print MSG024 % locals();         # I've only seen this on nodeagent JVM
      log( ' Exit: %s()' % funName );  #
      return;                          #
  else :                               #
    pd = pd[ 0 ];                      # Used by MSG023
    print MSG023 % locals();           #
    log( ' Exit: %s()' % funName );    #
    return;                            #

  #-----------------------------------------------------------------------------
  # Do we need to restore the verboseModeClass?
  #-----------------------------------------------------------------------------
  vmc = Old.get( 'verboseModeClass', '' ).strip();

  #-----------------------------------------------------------------------------
  # The jvmEntry should also have a 'verboseModeClass' attribute.
  #-----------------------------------------------------------------------------
  if jvmDict.has_key( 'verboseModeClass' ) :
    oldVMC = jvmDict[ 'verboseModeClass' ];
    if vmc and vmc != oldVMC :
      if vmc in [ 'false', 'true' ] :
        print MSG028 % locals();
        AdminConfig.modify( jvm, [ [ 'verboseModeClass', vmc ] ] );
        log( 'change( [ [ "verboseModeClass", "%s" ] ] )' % vmc );
      else :
        print MSG027 % locals();
        log( ' Exit: %s()' % funName );
        return;
  else :
    print MSG026 % locals();
    log( ' Exit: %s()' % funName );
    return;

  #-----------------------------------------------------------------------------
  # What are the current configuration property values?
  #-----------------------------------------------------------------------------
  ts  = AdminConfig.list( 'TraceService', serverId );
  tsD = WAuJ.showAsDict( ts );

  tl  = AdminConfig.list( 'TraceLog', ts );
  tlD = WAuJ.showAsDict( tl );

  #-----------------------------------------------------------------------------
  # Add the TraceLog dictionary name/value pairs to the TraceService dictionary
  #-----------------------------------------------------------------------------
  tsD.update( tlD );

  #-----------------------------------------------------------------------------
  # Is the specified server currently active?
  #-----------------------------------------------------------------------------
  try :
    if MBean :
      pid = AdminControl.getAttribute( MBean, 'pid' );
    else :
      pid = '';
  except :
    pid = '';

  #-----------------------------------------------------------------------------
  # Do any TraceServices changes need to be made?
  #-----------------------------------------------------------------------------
  changes = [];

  #-----------------------------------------------------------------------------
  # Were TraceServices enabled before the recreate was run?
  #-----------------------------------------------------------------------------
  enable0 = properties.get( 'enable', 'true' ).lower();    # Current  value
  enable1 = Old.get( 'enable', 'true' ).lower();           # Previous value
  if not enable0 :
    changes.append( [ 'enable', 'true' ] );
    properties[ 'enable' ] = 'true';
    log( 'change( [ [ "enable", "true" ] ] )' );
  elif enable0 != enable1 :
    changes.append( [ 'enable', enable1 ] );
    properties[ 'enable' ] = enable1;
    log( 'change( [ [ "enable", "%s" ] ] )' % enable1 );

  #-----------------------------------------------------------------------------
  # Does previous output type need to be restored?
  #-----------------------------------------------------------------------------
  ot0 = properties.get( 'traceOutputType', '' );
  ot1 = Old.get( 'traceOutputType', '' );
  if ot0 and ot0 != ot1 :
    changes.append( [ 'traceOutputType', ot1 ] );
    properties[ 'traceOutputType' ] = ot1;
    log( 'change( [ [ "traceOutputType", "%s" ] ] )' % ot1 );

  #-----------------------------------------------------------------------------
  # Does previous traceFormat type need to be restored?
  #-----------------------------------------------------------------------------
  tf0 = properties.get( 'traceFormat', '' );
  tf1 = Old.get( 'traceFormat', '' );
  if tf0 and tf0 != tf1 :
    changes.append( [ 'traceFormat', tf1 ] );
    properties[ 'traceFormat' ] = tf1;
    log( 'change( [ [ "traceFormat", "%s" ] ] )' % tf1 );

  #-----------------------------------------------------------------------------
  # Does previous traceSpecification need to be restored?
  #-----------------------------------------------------------------------------
  tS0 = properties.get( 'was.trace.string', '' );
  tS1 = Old.get( 'TraceString', '' );
  if tS0 and tS0 != tS1 :
    changes.append( [ 'startupTraceSpecification', tS1 ] );
    properties[ 'startupTraceSpecification' ] = tS1;
    log( 'change( [ [ "startupTraceSpecification", "%s" ] ] )' % tS1 );

  #-----------------------------------------------------------------------------
  # Are any TraceService changes needed?
  #-----------------------------------------------------------------------------
  error = None;
  if changes :
    parms = repr( changes ).replace( ',', '' );
    log( 'TraceService Changes: %s\n' % parms );

    try :
      AdminConfig.modify( ts, parms );
    except :
      t, v = sys.exc_info()[ :2 ];
      t, v = str( t ), str( v );
      pos = v.find( 'WASX' );
      if pos > -1 :
        v = v[ pos: ];
      print '%s() exception: %s' % ( funName, v );
      error = 1;

  #-----------------------------------------------------------------------------
  # If no error was encountered, are TraceLog changes needed?
  #-----------------------------------------------------------------------------
  if not error :
    changes = [];
#   #---------------------------------------------------------------------------
#   # Was the filename changed?
#   #---------------------------------------------------------------------------
#   fn0 = tlD.get( 'fileName', '' );        # Current  fileName
#   fn1 = Old.get( 'fileName', '' );        # Original fileName
#   if fn1 and fn0 != fn1 :
#     changes.append( [ 'fileName', fn1 ] );
    #---------------------------------------------------------------------------
    # Was the rolloverSize changed?
    #---------------------------------------------------------------------------
    ro0 = tlD.get( 'rolloverSize', '' );    # Current  rolloverSize
    ro1 = Old.get( 'LogSize', '' );         # Original rolloverSize
    if ro1 and ro0 != ro1 :
      changes.append( [ 'rolloverSize', ro1 ] );
      properties[ 'rolloverSize' ] = ro1;
      log( 'change( [ [ "rolloverSize", "%s" ] ] )' % ro1 );
    #---------------------------------------------------------------------------
    # What about the maxNumberOfBackupFiles?
    #---------------------------------------------------------------------------
    bu0 = tlD.get( 'maxNumberOfBackupFiles', '' );
    bu1 = Old.get( 'LogNumber', '' );
    if bu1 and bu0 != bu1 :
      changes.append( [ 'maxNumberOfBackupFiles', bu1 ] );
      properties[ 'maxNumberOfBackupFiles' ] = bu1;
      log( 'change( [ [ "maxNumberOfBackupFiles", "%s" ] ] )' % ro1 );

    #---------------------------------------------------------------------------
    # Are TraceLog changes needed?
    #---------------------------------------------------------------------------
    if changes :
      parms = repr( changes ).replace( ',', '' );
      log( 'TraceLog Changes: %s\n' % parms );

      try :
        AdminConfig.modify( tl, parms );
      except :
        t, v = sys.exc_info()[ :2 ];
        t, v = str( t ), str( v );
        pos = v.find( 'WASX' );
        if pos > -1 :
          v = v[ pos: ];
        print '%s() exception: %s' % ( funName, v );
        error = 1;

  #-----------------------------------------------------------------------------
  # If changes where made to the configuration, save them...
  #-----------------------------------------------------------------------------
  if not error and AdminConfig.queryChanges() :
    print MSG030 % locals();
    AdminConfig.save();
    updatePropfile( properties );
  else :
    print MSG031 % locals();

  #-----------------------------------------------------------------------------
  # Did the properties file request a server restart?
  #-----------------------------------------------------------------------------
  restart = properties.get( 'ReStartRequired', 'false' ).lower();
  if restart == 'true' :
    serverName = WAuJ.showAsDict( serverId )[ 'name' ];
    if MBean :
      print MSG032 % locals();
      try :
        AdminControl.invoke( MBean, 'restart' );
      except :
        print MSG033 % locals();
    else :
      print MSG033 % locals();

  log( ' Exit: %s()' % funName );


#-------------------------------------------------------------------------------
# Name: propfileAsDict()
# Role: Read the specified file, and parse its contents of name = values lines
#       into dictionary format
#-------------------------------------------------------------------------------
def propfileAsDict( filename ) :       #
  funName = WAuJ.callerName();         # Where are we?
  log( 'Enter: %s()' % funName );      #
  result = {};                         # start with an empty dictionary
  if os.path.isfile( filename ) :      # is the specified file of the right type?
    print MSG011 % locals();           #   Apparently so
    fh = open( filename );             #   Open it
    data = fh.read();                  #   Read the contents => data
    fh.close();                        #   Close the file
    for line in data.splitlines() :    #   For each line of text
      line = line.strip();             #    Remove leading & trailing blanks
      if line and not line.startswith( '#' ) : #    Is it empty & not a comment?
        name, value = line.split( '=', 1 );
        result[ name ] = value;        #      Save the value, indexed by the name
  else :                               #  Nope, not a "regular" file
    print MSG012 % locals();           #    tell the user, & ignore it
  result[ 'Old.contents' ] = data;     # Save the original file contents...
  result[ 'Old.filename' ] = filename; # ... and the input filename
  log( ' Exit: %s()' % funName );      #
  return result;                       #


#-------------------------------------------------------------------------------
# Name: updatePropfile()
# Role: Use the specified properties directory to rewrite the processed
#       properties file.
#-------------------------------------------------------------------------------
def updatePropfile( properties ) :     #
  funName = WAuJ.callerName();         # Where are we?
  log( 'Enter: %s()' % funName );      #
  Name = properties[ 'Old.filename' ]; #
  del( properties[ 'Old.filename' ] ); #
  try :                                #
    info = '\n'.join( [ '%s=%s' % ( name, properties[ name ] ) for name in properties.keys() ] );
    #---------------------------------------------------------------------------
    # info now contains only the original properties file "useful" lines
    #---------------------------------------------------------------------------
    log( 'Updated properties file contents:\n%s\n%s' % ( Delim, info ) );

    #---------------------------------------------------------------------------
    # Replace the properties files contents
    #---------------------------------------------------------------------------
    fh = open( Name, 'w' );            # This could fail if the file is R/O
    fh.write( info );                  #
    fh.close();                        #
  except IOError, e :                  # Write failure probably
    print MSG040 % ( funName, Name );  #
  except KeyError, k :                 # Dictionary element missing...
    print MSG041 % ( funName, k );     #
  except :                             # Something else
    kind, val = sys.exc_info()[ :2 ];  #
    kind, val = str( kind ), str( val );
    print MSG042 % locals();           #
  log( ' Exit: %s()' % funName );      #


#---------------------------------------------------------------------
# Name: Usage()
# Role: Routine used to provide user with information necessary to
#       use the script.
#---------------------------------------------------------------------
def Usage( cmdName = None ) :          # 
  #-------------------------------------------------------------------
  # Did the calling routine provide a value for cmdName? 
  #-------------------------------------------------------------------
  if not cmdName :                     # No, try to figure it out...
    #-----------------------------------------------------------------
    # Look for, and extract the -f <scriptFile.py> commandLine option
    #-----------------------------------------------------------------
    fOpt = re.compile( '.*-f ([^ ]*).*' );
    cmdLine = java.lang.System.getenv( 'IBM_JAVA_COMMAND_LINE' );
    matchObj = fOpt.search( cmdLine ); # See if the -f option exists
    if matchObj :                      # Does it occur in the cmdLine?
      cmdName = os.path.basename( matchObj.group( 1 ) ).split( '.', 1 )[ 0 ];
    else :                             #
      cmdName = 'imt-post';            # Default script name
  #-------------------------------------------------------------------
  # Display the usage information
  #-------------------------------------------------------------------
  print MSG000 % locals();             #
  sys.exit();                          #


#-------------------------------------------------------------------------------
# Name: main
# Role: This is the point at which "execution begins"
# Note: Verify that the script is being executed, and not imported
#-------------------------------------------------------------------------------
if ( __name__ == '__main__' ) or ( __name__ == 'main' ) :
  print MSG999 % locals();
  if WAuJ.configurable() :
    imt();
  else :
#   env_dump();
    print '''
Error: For some reason, the WebSphere Application Server (WSAS) scripting
       objects are not available.\n
       This can occur, for example, if wsadmin is connected to the SOAP
       port of a Managed Server, instead of to the Deployment Manager.\n
       This script can not function without accessing the WSAS scripting
       objects.\n
       Please correct this situation before using this script.
    '''
else :
  Usage( __name__ );
