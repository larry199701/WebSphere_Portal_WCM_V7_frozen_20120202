#!/bin/sh

export @name@=@value@

@command1@

@command2@