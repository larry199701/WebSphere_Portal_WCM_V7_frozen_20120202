#!/bin/sh

@command1@

@command2@