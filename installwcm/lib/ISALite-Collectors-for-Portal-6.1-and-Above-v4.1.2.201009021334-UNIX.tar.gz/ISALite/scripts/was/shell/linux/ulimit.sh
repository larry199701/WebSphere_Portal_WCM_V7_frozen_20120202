#!/bin/sh
ulimit -c unlimited
ulimit -u unlimited
