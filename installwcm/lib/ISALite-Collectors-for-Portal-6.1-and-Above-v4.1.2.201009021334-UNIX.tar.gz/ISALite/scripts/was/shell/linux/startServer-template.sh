#!/bin/sh
@ulimit-c@
@ulimit-u@
@was.enhanced.root@/bin/startServer.sh @serverName@
