set	MALLOCTRACE	1
set	MALLOC_TRACE @was.enhanced.root@
