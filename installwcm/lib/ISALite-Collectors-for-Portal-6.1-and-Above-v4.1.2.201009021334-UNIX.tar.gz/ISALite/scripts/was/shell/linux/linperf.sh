###############################################################################
#
# This script is used to collect data for 
# 'MustGather: Performance, Hang or High CPU Issues on Linux'
#
# You should only run one instance of this script at a time on the same machine.
#
# ./linperf.sh [PID_of_the_problematic_JVM]
#
###############################################################################

echo "MustGather>> linperf.sh script starting..."

# Set the first command line argument equal to the variable PROBLEMATIC_PID.
PROBLEMATIC_PID=@pid@

echo "MustGather>> PROBLEMATIC_PID is:  $PROBLEMATIC_PID" 

echo "MustGather>> Creating output files..."

# Create some of the output files with a blank line at top
echo > vmstat.out
echo > ps.out
echo > top.out
echo > topdashH.out

echo "MustGather>> Output files created:"
echo "MustGather>>      vmstat.out"
echo "MustGather>>      ps.out"
echo "MustGather>>      top.out"
echo "MustGather>>      topdashH.out"

echo "MustGather>> Starting collection of top data..."

# Start the collection of top data across the whole system.
# This will gather top data over four minutes.
# It runs in the background so that other tasks can be completed while this runs.
date >> top.out
echo >> top.out
top -bc -d 60 -n 5 >> top.out &

echo "MustGather>> Collection of top data started."

echo "MustGather>> Starting collection of top dash H data..."

# Start the collection of top -H.
# This will gather top data over four minutes.
# It runs in the background so that other tasks can be completed while this runs.
date >> topdashH.out
echo >> topdashH.out
top -bH -d 5 -n 48 -p $PROBLEMATIC_PID >> topdashH.out &

echo "MustGather>> Collection of top dash H data started."

echo "MustGather>> Collecting the first ps snapshot..."

# Collect the first ps: date at the top, data, and then a blank line
date >> ps.out
ps -eLf >> ps.out
echo >> ps.out

echo "MustGather>> First ps snapshot complete."

echo "MustGather>> Collecting the first javacore..."

# Collect the first javacore against the problematic pid (passed in by the user)
# Javacores are output to the working directory of the JVM; in most cases this is the <profile_root>
kill -3 $PROBLEMATIC_PID

echo "MustGather>> First javacore complete."

echo "MustGather>> Collecting the first vmstat snapshot.  This will take a minute..."

# Collect the first vmstat: date at the top, data, and then a blank line
# These arguments for vmstat will cause it to take 12 samples 5 seconds apart for a total of 60 seconds.
date >> vmstat.out
vmstat 5 12 >> vmstat.out
echo >> vmstat.out

echo "MustGather>> First vmstat snapshot complete."

echo "MustGather>> Pause for 60 seconds..."

# Pause for 60 seconds.
sleep 60

echo "MustGather>> Collecting the second ps snapshot..."

# Collect another round of ps data.
date >> ps.out
ps -eLf >> ps.out
echo >> ps.out

echo "MustGather>> Second ps snapshot complete."

echo "MustGather>> Collecting the second javacore..." 

# Collect another javacore.
kill -3 $PROBLEMATIC_PID

echo "MustGather>> Second javacore complete."

echo "MustGather>> Collecting the second vmstat snapshot.  This will take a minute..."

# Collect another round of vmstat data.
date >> vmstat.out
vmstat 5 12 >> vmstat.out
echo >> vmstat.out

echo "MustGather>> Second vmstat snapshot complete."

echo "MustGather>> Pause for 60 seconds..."

# Pause for 60 seconds.
sleep 60

echo "MustGather>> Collecting the final ps snapshot..."

# Collect the final ps data.
date >> ps.out
ps -eLf >> ps.out
echo >> ps.out

echo "MustGather>> Final ps snapshot complete."

echo "MustGather>> Collecting the final javacore..."

# Collect a final javacore
kill -3 $PROBLEMATIC_PID

echo "MustGather>> Final javacore complete."

echo "MustGather>> Collecting the final vmstat snapshot.  This will take a minute..."

# Collect the final vmstat data
date >> vmstat.out
vmstat 5 12 >> vmstat.out
echo >> vmstat.out

echo "MustGather>> Final vmstat snapshot complete."

echo "MustGather>> Compress output files into linperf_RESULTS.tar.gz"

# Tar the vmstat, ps, and top output files together
tar -cvf linperf_RESULTS.tar vmstat.out ps.out top.out topdashH.out

# GZip the tar file to create linperf_RESULTS.tar.gz
gzip linperf_RESULTS.tar

echo "MustGather>> Remove the temporary output files as they have now been added to the linperf_RESULTS.tar.gz file."

# Clean up the output files now that they have been tar/gz'd.
rm vmstat.out ps.out top.out topdashH.out

echo "MustGather>> Output files removed."
echo "MustGather>> linperf.sh script complete."
echo
echo "MustGather>> Output files are contained within ---->   linperf_RESULTS.tar.gz.   <----"
echo "MustGather>> The javacores that were created are NOT included in the linperf_RESULTS.tar.gz."
echo "MustGather>> Check the <profile_root> for the javacores.  Be sure to submit these along with the above file."
