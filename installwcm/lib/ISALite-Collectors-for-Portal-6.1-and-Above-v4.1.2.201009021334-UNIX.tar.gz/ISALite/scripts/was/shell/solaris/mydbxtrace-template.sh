#!/bin/sh
@dbxtrace.path@ @java.path@ @core.path@ >@dbxtrace.out@
