#!/bin/sh
# Script runs for approximately 2 minutes.
# The parameter is the process ID of the App Server that has high CPU.

# Assign parameter value to PID variable
PID=@pid@

# Gather environment information.
env > env.out
ulimit -a > ulimit.out
uname -a > uname.out
showrev -p > showrev.out
pkginfo -l > pkginfo.out

# Stat commands which run in the background over the 2 minute period.
/usr/bin/netstat -an > netstat.out &
/usr/bin/vmstat 10 20 > vmstat.out &
/usr/bin/prstat -mvcLn 40 -p $PID 10 20 > prstatpid.out &
/usr/bin/prstat -n 5 10 20 > prstatsys.out &
/usr/bin/mpstat 10 20 > mpstat.out &

# lsof and proc tools executed once only, at the start of the 2 minutes.
/usr/local/bin/lsof -p $PID > lsof.out 
/usr/bin/pfiles $PID > pfiles.out  
/usr/bin/pmap $PID > pmap.out 
/usr/bin/pldd $PID > pldd.out 

# Java thread dumps pstacks are taken over the course of the 2 minutes.
# May need to increase the resolution of this section (more pstacks, less
# time delay between them) if there are spikes in prstat output. 
date > pstack1.out
/usr/bin/pstack $PID >> pstack1.out  
kill -3 $PID 
sleep 120

date > pstack2.out
/usr/bin/pstack $PID >> pstack2.out 
kill -3 $PID 
sleep 120

date > pstack3.out
/usr/bin/pstack $PID >> pstack3.out 
kill -3 $PID

# Compress all the files that we have just created.
tar -cvf solperf_RESULTS.tar env.out ulimit.out uname.out showrev.out pkginfo.out netstat.out vmstat.out prstatpid.out prstatsys.out mpstat.out lsof.out pfiles.out pmap.out pldd.out pstack1.out pstack2.out pstack3.out
gzip solperf_RESULTS.tar

# Remove .out files that have just been tar.gz'd together
rm env.out ulimit.out uname.out showrev.out pkginfo.out netstat.out vmstat.out prstatpid.out prstatsys.out mpstat.out lsof.out pfiles.out pmap.out pldd.out pstack1.out pstack2.out pstack3.out
