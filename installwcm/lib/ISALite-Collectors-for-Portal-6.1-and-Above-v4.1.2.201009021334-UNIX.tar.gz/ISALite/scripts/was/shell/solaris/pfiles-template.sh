#!/bin/sh
/usr/proc/bin/pfiles @pid@ > @pfiles.out@
/usr/proc/bin/pmap @pid@ > @pmap.out@
