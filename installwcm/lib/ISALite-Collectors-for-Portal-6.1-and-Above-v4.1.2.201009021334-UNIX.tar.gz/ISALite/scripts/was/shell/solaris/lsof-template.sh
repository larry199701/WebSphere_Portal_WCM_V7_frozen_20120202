#!/bin/sh
lsof -p @pid@ > @lsof.out@
