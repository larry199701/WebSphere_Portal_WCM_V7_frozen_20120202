#!/bin/sh
ulimit -c unlimited
