#!/bin/sh
@ulimit-c@
@was.enhanced.root@/bin/startServer.sh @serverName@
