#!/bin/sh
/usr/proc/bin/pstack @pid@ >@pstack.out@
