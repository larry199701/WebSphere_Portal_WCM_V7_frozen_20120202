#!/bin/sh
@gdbtrace.path@ @java.path@ @core.path@ >@gdbtrace.out@
