#!/bin/sh
@jextract.path@ @core.sdff@ @core.path@ 
