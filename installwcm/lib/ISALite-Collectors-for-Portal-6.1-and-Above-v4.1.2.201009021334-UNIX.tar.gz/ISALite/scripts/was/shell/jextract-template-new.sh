#!/bin/sh
@jextract.path@ @core.path@
