#!/bin/sh
export PATH=$PATH:@gskit.home@/lib:@gskit.home@/bin
@gskit.command@
