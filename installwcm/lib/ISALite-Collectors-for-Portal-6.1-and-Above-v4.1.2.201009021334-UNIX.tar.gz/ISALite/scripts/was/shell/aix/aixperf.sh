#!/bin/ksh
###############################################################################
#
# This script is used to collect data for 
# 'MustGather: Performance, Hang or High CPU Issues on AIX'
#
# You should only run one instance of this script at a time on the same machine.
#
# ./aixperf.sh [PID_of_the_problematic_JVM]
#
###############################################################################

print "MustGather>> aixperf.sh script starting..."

# Set the first command line argument equal to the variable PROBLEMATIC_PID.
PROBLEMATIC_PID=@pid@

print "MustGather>> PROBLEMATIC_PID is:  $PROBLEMATIC_PID" 

print "MustGather>> Creating output files..."

# Create some of the output files with a blank line at top
echo > netstat.out
echo > vmstat.out
echo > ps.out

print "MustGather>> Output files created:"
print "MustGather>>      netstat.out"
print "MustGather>>      vmstat.out"
print "MustGather>>      ps.out"

print "MustGather>> Collecting the first netstat snapshot..."

# Collect the first netstat: date at the top, data, and then a blank line
date >> netstat.out
netstat -an >> netstat.out
echo >> netstat.out

print "MustGather>> First netstat snapshot complete."

print "MustGather>> Collecting the first ps snapshot..."

# Collect the first ps: date at the top, data, and then a blank line
date >> ps.out
ps avwwwg >> ps.out
echo >> ps.out

print "MustGather>> First ps snapshot complete."

print "MustGather>> Collecting the first javacore..."

# Collect the first javacore against the problematic pid (passed in by the user)
# Javacores are output to the working directory of the JVM; in most cases this is the <profile_root>
kill -3 $PROBLEMATIC_PID

print "MustGather>> First javacore complete."

print "MustGather>> Collecting the first vmstat snapshot.  This will take a minute..."

# Collect the first vmstat: date at the top, data, and then a blank line
# These arguments for vmstat will cause it to take 12 samples 5 seconds apart for a total of 60 seconds.
date >> vmstat.out
vmstat 5 12 >> vmstat.out
echo >> vmstat.out

print "MustGather>> First vmstat snapshot complete."

print "MustGather>> Collecting tprof data.  This will take a minute..."

# Collect the tprof data.
# The tprof command here outputs a file named sleep.prof.
# This takes 60 seconds to run.
tprof -skex sleep 60

print "MustGather>> tprof data complete.  Output sent to:   sleep.prof"

print "MustGather>> Collecting the second ps snapshot..."

# Collect another round of ps data.
date >> ps.out
ps avwwwg >> ps.out
echo >> ps.out

print "MustGather>> Second ps snapshot complete."

print "MustGather>> Collecting the second javacore..." 

# Collect another javacore.
kill -3 $PROBLEMATIC_PID

print "MustGather>> Second javacore complete."

print "MustGather>> Collecting the second vmstat snapshot.  This will take a minute..."

# Collect another round of vmstat data.
date >> vmstat.out
vmstat 5 12 >> vmstat.out
echo >> vmstat.out

print "MustGather>> Second vmstat snapshot complete."

print "MustGather>> Pause for 60 seconds..."

# Pause for 60 seconds.
sleep 60

print "MustGather>> Collecting the final ps snapshot..."

# Collect the final ps data.
date >> ps.out
ps avwwwg >> ps.out
echo >> ps.out

print "MustGather>> Final ps snapshot complete."

print "MustGather>> Collecting the final javacore..."

# Collect a final javacore
kill -3 $PROBLEMATIC_PID

print "MustGather>> Final javacore complete."

print "MustGather>> Collecting the final vmstat snapshot.  This will take a minute..."

# Collect the final vmstat data
date >> vmstat.out
vmstat 5 12 >> vmstat.out
echo >> vmstat.out

print "MustGather>> Final vmstat snapshot complete."

print "MustGather>> Collecting the final netstat snapshot..."

# Collect a final netstat
date >> netstat.out
netstat -an >> netstat.out
echo >> netstat.out

print "MustGather>> Final netstat snapshot complete."

print "MustGather>> Compress output files into aixperf_RESULTS.tar.gz"

# Tar the netstat, vmstat, ps, and sleep.prof files together
tar -cvf aixperf_RESULTS.tar netstat.out vmstat.out ps.out sleep.prof

# GZip the tar file to create aixperf_RESULTS.tar.gz
gzip aixperf_RESULTS.tar

print "MustGather>> Remove the temporary output files as they have now been added to the aixperf_RESULTS.tar.gz file."

# Clean up the output files now that they have been tar/gz'd.
rm netstat.out
rm vmstat.out
rm ps.out
rm sleep.prof

print "MustGather>> Output files removed."
print "MustGather>> aixperf.sh script complete."
echo
print "MustGather>> Output files are contained within ---->   aixperf_RESULTS.tar.gz.   <----"
print "MustGather>> The javacores that were created are NOT included in the aixperf_RESULTS.tar.gz."
print "MustGather>> Check the <profile_root> for the javacores.  Be sure to submit these along with the above file."
