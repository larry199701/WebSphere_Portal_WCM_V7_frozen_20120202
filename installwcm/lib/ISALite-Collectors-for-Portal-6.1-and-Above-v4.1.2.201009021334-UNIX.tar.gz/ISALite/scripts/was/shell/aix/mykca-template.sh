#!/bin/sh
@kca.path@ -j@num@ @core.path@ -d > @kca.out@ 
