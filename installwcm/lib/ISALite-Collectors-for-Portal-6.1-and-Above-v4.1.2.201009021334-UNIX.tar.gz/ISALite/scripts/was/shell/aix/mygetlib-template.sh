#!/bin/sh
@getlib.sh@ @java.path@ @core.path@
