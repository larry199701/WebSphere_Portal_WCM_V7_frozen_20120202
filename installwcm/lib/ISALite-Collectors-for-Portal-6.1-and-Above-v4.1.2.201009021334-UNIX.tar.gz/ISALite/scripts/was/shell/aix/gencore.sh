#!/bin/sh
gencore @pid@ @core.path@
