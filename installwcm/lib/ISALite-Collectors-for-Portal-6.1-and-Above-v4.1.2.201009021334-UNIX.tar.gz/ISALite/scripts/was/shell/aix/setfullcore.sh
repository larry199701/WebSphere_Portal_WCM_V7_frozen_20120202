#!/bin/sh
chdev -a fullcore=true -lsys0
