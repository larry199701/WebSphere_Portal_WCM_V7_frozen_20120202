export LDR_CNTRL=MAXDATA=0x@n@0000000
@was.enhanced.root@/bin/startServer.sh @serverName@
