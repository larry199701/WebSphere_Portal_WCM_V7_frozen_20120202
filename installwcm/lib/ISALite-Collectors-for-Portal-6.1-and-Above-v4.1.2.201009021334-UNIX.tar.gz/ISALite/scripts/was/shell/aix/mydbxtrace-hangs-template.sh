#!/bin/sh
@dbxtrace.path@ -a @pid@ > @dbxtrace.out@
