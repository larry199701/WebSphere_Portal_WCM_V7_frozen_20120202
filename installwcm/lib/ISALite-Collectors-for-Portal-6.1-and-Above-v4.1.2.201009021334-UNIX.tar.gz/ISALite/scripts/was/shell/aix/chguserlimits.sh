#!/bin/sh
chuser fsize=-1 data=-1 core=-1 root
