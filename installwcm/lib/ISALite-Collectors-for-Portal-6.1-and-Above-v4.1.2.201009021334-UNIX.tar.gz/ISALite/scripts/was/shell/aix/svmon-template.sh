#!/bin/sh
svmon @args@ > @svmon.out@
