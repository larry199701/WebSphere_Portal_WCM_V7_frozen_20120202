#!/bin/sh
tprof -k -s -e -x sleep 60
