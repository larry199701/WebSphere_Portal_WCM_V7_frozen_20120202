#!/bin/sh
@ulimit-c@
@ulimit-f@
@was.enhanced.root@/bin/startServer.sh @serverName@
