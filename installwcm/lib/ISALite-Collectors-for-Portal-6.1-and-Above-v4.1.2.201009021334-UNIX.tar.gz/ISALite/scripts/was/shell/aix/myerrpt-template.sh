#!/bin/sh
@errpt.command@ -a > @errpt.out@
