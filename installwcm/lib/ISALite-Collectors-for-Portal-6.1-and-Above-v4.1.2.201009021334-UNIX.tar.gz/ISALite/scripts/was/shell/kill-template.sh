#!/bin/sh
kill @num@ @pid@
