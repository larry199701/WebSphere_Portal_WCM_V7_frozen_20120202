echo "Collecting top data"
top -s5 -d60 > top_cpu.out
 
