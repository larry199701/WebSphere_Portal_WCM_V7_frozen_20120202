#!/bin/sh
/opt/langtools/bin/gdb @java.path@ @core.path@ 
packcore
