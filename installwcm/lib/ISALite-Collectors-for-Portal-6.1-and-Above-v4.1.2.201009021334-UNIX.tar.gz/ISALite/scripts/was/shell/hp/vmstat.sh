echo "Collecting vmstat data"
vmstat 5 60> vmstat_cpu.out
