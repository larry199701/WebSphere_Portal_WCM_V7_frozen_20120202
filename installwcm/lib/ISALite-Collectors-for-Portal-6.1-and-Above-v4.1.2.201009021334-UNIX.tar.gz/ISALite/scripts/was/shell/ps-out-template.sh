#!/bin/sh
ps @ps.args@ >@ps.out@
