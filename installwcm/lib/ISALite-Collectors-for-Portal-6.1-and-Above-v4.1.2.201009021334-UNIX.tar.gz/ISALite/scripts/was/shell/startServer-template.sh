#!/bin/sh
@define_variables@
@was.enhanced.root@/bin/startServer.sh @serverName@
